package com.joy.viaauto

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvAccessibilityStatus: TextView
    private lateinit var tvOverlayStatus: TextView
    private lateinit var etDefaultPassword: EditText
    private lateinit var etGrabMailKey: EditText
    private lateinit var tvSavedHeader: TextView
    private lateinit var tvEmptySaved: TextView
    private lateinit var llSavedContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus)
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        etDefaultPassword = findViewById(R.id.etDefaultPassword)
        etGrabMailKey = findViewById(R.id.etGrabMailKey)
        tvSavedHeader = findViewById(R.id.tvSavedHeader)
        tvEmptySaved = findViewById(R.id.tvEmptySaved)
        llSavedContainer = findViewById(R.id.llSavedContainer)

        etDefaultPassword.setText(VaultManager.getDefaultPassword(this))
        etGrabMailKey.setText(VaultManager.getGrabMailKey(this))

        findViewById<Button>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnEnableOverlay).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnStartWork).setOnClickListener {
            VaultManager.saveSettings(
                this,
                etDefaultPassword.text.toString(),
                etGrabMailKey.text.toString()
            )
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please enable Floating Overlay permission first", Toast.LENGTH_SHORT).show()
                findViewById<Button>(R.id.btnEnableOverlay).performClick()
                return@setOnClickListener
            }
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Please enable Accessibility Service first", Toast.LENGTH_SHORT).show()
                findViewById<Button>(R.id.btnEnableAccessibility).performClick()
                return@setOnClickListener
            }

            AutomationState.startNewSession(this)
            FloatingOverlayService.start(this)
            AutomationState.openUrlInVia(this, AutomationState.URL_MUSE_SIGNUP)
        }

        findViewById<Button>(R.id.btnAddManual).setOnClickListener {
            showManualAddDialog()
        }

        findViewById<Button>(R.id.btnClearAll).setOnClickListener {
            VaultManager.clearAll(this)
            renderSavedRecords()
            Toast.makeText(this, "All saved data cleared", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionIndicators()
        renderSavedRecords()
    }

    private fun updatePermissionIndicators() {
        val accOn = isAccessibilityEnabled()
        tvAccessibilityStatus.text = if (accOn) "Accessibility Service: ON" else "Accessibility Service: OFF"
        tvAccessibilityStatus.setTextColor(
            ContextCompat.getColor(this, if (accOn) R.color.accent_green else R.color.accent_red)
        )

        val ovOn = Settings.canDrawOverlays(this)
        tvOverlayStatus.text = if (ovOn) "Floating Overlay: ON" else "Floating Overlay: OFF"
        tvOverlayStatus.setTextColor(
            ContextCompat.getColor(this, if (ovOn) R.color.accent_green else R.color.accent_red)
        )
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any {
            it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == ViaAutomationService::class.java.name
        }
    }

    private fun renderSavedRecords() {
        val records = VaultManager.getRecords(this)
        tvSavedHeader.text = "Saved Data (${records.size})"
        llSavedContainer.removeAllViews()

        if (records.isEmpty()) {
            tvEmptySaved.visibility = View.VISIBLE
            return
        }
        tvEmptySaved.visibility = View.GONE

        val inflater = LayoutInflater.from(this)
        for (record in records) {
            val itemView = inflater.inflate(R.layout.item_saved_account, llSavedContainer, false)
            itemView.findViewById<TextView>(R.id.tvItemTime).text = record.timestamp
            itemView.findViewById<TextView>(R.id.tvItemNumber).text = "Number/Mail: ${record.numberOrEmail.ifBlank { "-" }}"
            itemView.findViewById<TextView>(R.id.tvItemPassword).text = "Password: ${record.password.ifBlank { "-" }}"
            itemView.findViewById<TextView>(R.id.tvItemTwoFa).text = "2FA: ${record.twoFa.ifBlank { "-" }}"

            itemView.findViewById<Button>(R.id.btnCopyNumber).setOnClickListener {
                copyToClipboard("Number/Mail", record.numberOrEmail)
            }
            itemView.findViewById<Button>(R.id.btnCopyPassword).setOnClickListener {
                copyToClipboard("Password", record.password)
            }
            itemView.findViewById<Button>(R.id.btnCopyTwoFa).setOnClickListener {
                copyToClipboard("2FA", record.twoFa)
            }
            itemView.findViewById<Button>(R.id.btnCopyAllItem).setOnClickListener {
                val combined = "${record.numberOrEmail} | ${record.password} | ${record.twoFa}"
                copyToClipboard("Account", combined)
            }
            itemView.findViewById<Button>(R.id.btnDeleteItem).setOnClickListener {
                VaultManager.deleteRecord(this, record.id)
                renderSavedRecords()
            }
            llSavedContainer.addView(itemView)
        }
    }

    private fun showManualAddDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 8)
        }
        val etNum = EditText(this).apply { hint = "Number or Email" }
        val etPass = EditText(this).apply { hint = "Password" }
        val et2fa = EditText(this).apply { hint = "2FA Key" }
        container.addView(etNum)
        container.addView(etPass)
        container.addView(et2fa)

        AlertDialog.Builder(this)
            .setTitle("Save Number / Password / 2FA")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                VaultManager.addOrUpdateRecord(
                    this,
                    AccountRecord(
                        numberOrEmail = etNum.text.toString().trim(),
                        password = etPass.text.toString().trim(),
                        twoFa = et2fa.text.toString().trim()
                    )
                )
                renderSavedRecords()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun copyToClipboard(label: String, text: String) {
        if (text.isBlank()) {
            Toast.makeText(this, "$label is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "$label copied", Toast.LENGTH_SHORT).show()
    }
}
