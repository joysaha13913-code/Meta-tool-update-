package com.joy.viaauto

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

class ViaAutomationService : AccessibilityService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val isPollingOtp = AtomicBoolean(false)
    private var lastActionTimestamp = 0L

    private var lastSessionId = ""
    private var emailSubmitted = false
    private var otpSubmitted = false
    private var nameDobSubmitted = false
    private var passwordSubmitted = false
    private var openedAccountsCenter = false

    private var numberAdded = false
    private var emailDeleted = false
    private var twoFaKeyCaptured = false
    private var deviceNameSubmitted = false
    private var totpSubmitted = false

    private val firstNames = listOf("Rashed", "Tariq", "Arif", "Nabil", "Sajib", "Kamrul", "Hasan", "Imran", "Farhan", "Mahmud")
    private val lastNames = listOf("Mia", "Ahmed", "Rahman", "Islam", "Khan", "Hossain", "Chowdhury", "Sarkar")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !AutomationState.isRunning) return
        val pkg = event.packageName?.toString() ?: ""
        if (pkg != "mark.via.gp" && pkg != "mark.via") return

        if (lastSessionId != AutomationState.currentRecordId) {
            lastSessionId = AutomationState.currentRecordId
            resetFlags()
        }

        val now = System.currentTimeMillis()
        if (now - lastActionTimestamp < 1200L) return

        val root = rootInActiveWindow ?: return
        val nodes = collectAllNodes(root)
        if (nodes.isEmpty()) return

        val pageText = nodes.mapNotNull {
            val t = it.text?.toString() ?: ""
            val d = it.contentDescription?.toString() ?: ""
            "$t $d".trim()
        }.joinToString(" | ")

        // 1. Email Entry on muse.ai/?aymh_complete=1
        if (!emailSubmitted &&
            (pageText.contains("Log in or create an account", ignoreCase = true) ||
             pageText.contains("Mobile number or email address", ignoreCase = true) ||
             pageText.contains("Muse", ignoreCase = true)) &&
            !pageText.contains("Enter your code", ignoreCase = true) &&
            !pageText.contains("Finish creating your account", ignoreCase = true) &&
            !pageText.contains("Login and security", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val continueBtn = findNodeByText(nodes, "Continue")
            if (edits.isNotEmpty() && continueBtn != null) {
                lastActionTimestamp = now
                emailSubmitted = true

                val email = GrabMailClient.generateRandomEmail()
                AutomationState.currentEmail = email
                AutomationState.currentStep = AutomationState.Step.WAIT_OTP
                AutomationState.updateStatus("Step 1: GrabMail -> $email")
                AutomationState.log("Generated GrabMail: $email")
                saveCurrentRecord()

                setTextOnNode(edits.first(), email)
                mainHandler.postDelayed({
                    if (AutomationState.isRunning) {
                        val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                        findNodeByText(latest, "Continue")?.let {
                            clickNodeOrParent(it)
                            AutomationState.log("Clicked Continue after email.")
                        }
                    }
                }, 700L)
                return
            }
        }

        // 2. 6-Digit OTP Verification
        if (!otpSubmitted &&
            (pageText.contains("Enter your code to sign up", ignoreCase = true) ||
             pageText.contains("6-digit code", ignoreCase = true))
        ) {
            if (!isPollingOtp.get() && AutomationState.currentEmail.isNotEmpty()) {
                lastActionTimestamp = now
                startOtpPolling()
            }
            return
        }

        // Optional Password Screen
        if (!passwordSubmitted &&
            pageText.contains("Password", ignoreCase = true) &&
            pageText.contains("Get started on Meta AI", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val continueBtn = findNodeByText(nodes, "Continue")
            if (edits.isNotEmpty() && continueBtn != null) {
                lastActionTimestamp = now
                passwordSubmitted = true
                setTextOnNode(edits.last(), AutomationState.currentPassword)
                AutomationState.log("Filled Password.")
                saveCurrentRecord()
                mainHandler.postDelayed({
                    if (AutomationState.isRunning) {
                        val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                        findNodeByText(latest, "Continue")?.let { clickNodeOrParent(it) }
                    }
                }, 700L)
                return
            }
        }

        // 3. Name & Date of Birth
        if (!nameDobSubmitted &&
            (pageText.contains("Finish creating your account", ignoreCase = true) ||
             (pageText.contains("First name", ignoreCase = true) && pageText.contains("Last name", ignoreCase = true)))
        ) {
            val edits = findEditableNodes(nodes)
            if (edits.size >= 2) {
                lastActionTimestamp = now
                nameDobSubmitted = true
                val fName = firstNames.random()
                val lName = lastNames.random()
                AutomationState.currentStep = AutomationState.Step.WAIT_NAME_DOB
                AutomationState.updateStatus("Step 3: Name ($fName $lName) & DOB")
                AutomationState.log("Filling Name: $fName $lName")

                setTextOnNode(edits[0], fName)
                mainHandler.postDelayed({
                    if (!AutomationState.isRunning) return@postDelayed
                    setTextOnNode(edits[1], lName)
                    mainHandler.postDelayed({
                        if (!AutomationState.isRunning) return@postDelayed
                        val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                        val yearNode = findNodeByText(latest, "2026")
                        if (yearNode != null) {
                            clickNodeOrParent(yearNode)
                            mainHandler.postDelayed({
                                val popNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                                val adultYear = findNodeByText(popNodes, "1999")
                                    ?: findNodeByText(popNodes, "2000")
                                    ?: findNodeByText(popNodes, "1998")
                                    ?: findNodeByText(popNodes, "2001")
                                adultYear?.let { clickNodeOrParent(it) }
                                clickConfirmAndOpenAccountsCenter()
                            }, 800L)
                        } else {
                            clickConfirmAndOpenAccountsCenter()
                        }
                    }, 600L)
                }, 400L)
                return
            }
        }

        // 4. Accounts Center: Add Number -> Delete Email -> Setup 2FA
        // 4a. If on Two-factor authentication "Get started" BEFORE number added & email deleted -> go back or open Contact info
        if (pageText.contains("Login and security", ignoreCase = true)) {
            if (!numberAdded || !emailDeleted) {
                findNodeByText(nodes, "Contact info")?.let {
                    lastActionTimestamp = now
                    AutomationState.updateStatus("Step 4: Opening Contact info")
                    clickNodeOrParent(it)
                    AutomationState.log("Opened Contact info.")
                    return
                }
            } else if (!twoFaKeyCaptured) {
                findNodeByText(nodes, "Two-factor authentication")?.let {
                    lastActionTimestamp = now
                    AutomationState.updateStatus("Step 5: Opening 2FA Setup")
                    clickNodeOrParent(it)
                    AutomationState.log("Opened Two-factor authentication.")
                    return
                }
            }
        }

        // 4b. Contact Info screen
        if (pageText.contains("Contact info", ignoreCase = true) &&
            pageText.contains("Add new contact info", ignoreCase = true)
        ) {
            if (!numberAdded && !pageText.contains("+880")) {
                findNodeByText(nodes, "Add new contact info")?.let {
                    lastActionTimestamp = now
                    clickNodeOrParent(it)
                    AutomationState.log("Tapped Add new contact info.")
                    return
                }
            } else if (pageText.contains("+880") && !emailDeleted) {
                numberAdded = true
                val grabMailNode = nodes.firstOrNull {
                    (it.text?.toString() ?: "").contains("@grabmail.io", ignoreCase = true)
                }
                if (grabMailNode != null) {
                    lastActionTimestamp = now
                    clickNodeOrParent(grabMailNode)
                    AutomationState.log("Selected temp email to delete.")
                    return
                } else {
                    emailDeleted = true
                }
            } else if (numberAdded && emailDeleted && !twoFaKeyCaptured) {
                // Navigate back to Login and security or directly open 2FA URL
                lastActionTimestamp = now
                AutomationState.log("Number added & email deleted. Opening 2FA...")
                AutomationState.openUrlInVia(this, AutomationState.URL_META_2FA)
                return
            }
        }

        // 4c. "Add mobile number" option in bottom sheet
        if (!numberAdded && pageText.contains("Add mobile number", ignoreCase = true) &&
            !pageText.contains("Enter mobile number", ignoreCase = true)
        ) {
            findNodeByText(nodes, "Add mobile number")?.let {
                lastActionTimestamp = now
                clickNodeOrParent(it)
                AutomationState.log("Selected Add mobile number.")
                return
            }
        }

        // 4d. Enter mobile number screen ("Bangladesh (+880)" + "Enter mobile number")
        if (!numberAdded &&
            (pageText.contains("Enter mobile number", ignoreCase = true) ||
             pageText.contains("Add mobile number", ignoreCase = true)) &&
            pageText.contains("Next", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val nextBtn = findNodeByText(nodes, "Next")
            if (edits.isNotEmpty() && nextBtn != null) {
                lastActionTimestamp = now
                numberAdded = true
                val bd10 = AutomationState.generateRandomBdNumber10Digits()
                val fullNum = "0$bd10"
                AutomationState.currentNumber = fullNum
                AutomationState.updateStatus("Step 4: Adding Number $fullNum")
                AutomationState.log("Entering BD Number: $bd10 (saved as $fullNum)")
                saveCurrentRecord()

                setTextOnNode(edits.first(), bd10)
                mainHandler.postDelayed({
                    if (AutomationState.isRunning) {
                        val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                        findNodeByText(latest, "Next")?.let {
                            clickNodeOrParent(it)
                            AutomationState.log("Clicked Next after adding number.")
                        }
                    }
                }, 800L)
                return
            }
        }

        // 4e. Delete email address screens
        if (!emailDeleted && pageText.contains("Delete email address", ignoreCase = true)) {
            val deleteConfirm = findNodeByText(nodes, "Delete")
            val deleteEmailBtn = findNodeByText(nodes, "Delete email address")
            lastActionTimestamp = now
            if (pageText.contains("Delete email address?", ignoreCase = true) && deleteConfirm != null) {
                emailDeleted = true
                clickNodeOrParent(deleteConfirm)
                AutomationState.log("Confirmed Delete email address.")
                return
            } else if (deleteEmailBtn != null) {
                clickNodeOrParent(deleteEmailBtn)
                AutomationState.log("Tapped Delete email address.")
                return
            }
        }

        // 5. 2FA Setup Flow
        if (pageText.contains("Set up extra protection", ignoreCase = true)) {
            if (!numberAdded) {
                // Close modal or go back to Login and security first to add number & delete email
                val closeBtn = findNodeByText(nodes, "Close") ?: nodes.firstOrNull {
                    (it.contentDescription?.toString() ?: "").contains("Close", ignoreCase = true)
                }
                if (closeBtn != null) {
                    lastActionTimestamp = now
                    clickNodeOrParent(closeBtn)
                    AutomationState.log("Closed 2FA modal to add number first.")
                    return
                }
            } else {
                findNodeByText(nodes, "Get started")?.let {
                    lastActionTimestamp = now
                    clickNodeOrParent(it)
                    AutomationState.log("Tapped Get started for 2FA.")
                    return
                }
            }
        }

        if (pageText.contains("Help protect your account", ignoreCase = true) &&
            pageText.contains("Authentication app", ignoreCase = true)
        ) {
            lastActionTimestamp = now
            findNodeByText(nodes, "Authentication app")?.let { clickNodeOrParent(it) }
            mainHandler.postDelayed({
                val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                findNodeByText(latest, "Continue")?.let {
                    clickNodeOrParent(it)
                    AutomationState.log("Selected Authentication app -> Continue.")
                }
            }, 600L)
            return
        }

        // 5a. Instructions for setup -> Extract Base32 Key & click Next
        if (!twoFaKeyCaptured &&
            pageText.contains("Instructions for setup", ignoreCase = true) &&
            pageText.contains("Copy key", ignoreCase = true)
        ) {
            val keyMatch = Regex("\\b([A-Z2-7]{4}(?:\\s+[A-Z2-7]{4}){3,7})\\b").find(pageText)
            val candidate = keyMatch?.groupValues?.getOrNull(1)?.replace(Regex("\\s+"), "") ?: ""
            if (candidate.length >= 16 && candidate != "LOGINANDSECURITY") {
                lastActionTimestamp = now
                twoFaKeyCaptured = true
                AutomationState.currentTwoFa = candidate
                AutomationState.updateStatus("Step 5: Captured 2FA Key")
                AutomationState.log("Captured 2FA Key: $candidate")
                saveCurrentRecord()

                findNodeByText(nodes, "Next")?.let {
                    clickNodeOrParent(it)
                    AutomationState.log("Clicked Next after capturing 2FA key.")
                }
                return
            }
        }

        // 5b. Connect device -> Enter device name -> Next
        if (!deviceNameSubmitted &&
            pageText.contains("Connect device", ignoreCase = true) &&
            pageText.contains("Name", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val nextBtn = findNodeByText(nodes, "Next")
            if (edits.isNotEmpty() && nextBtn != null) {
                lastActionTimestamp = now
                deviceNameSubmitted = true
                setTextOnNode(edits.first(), "Device1")
                AutomationState.log("Entered device name: Device1")
                mainHandler.postDelayed({
                    val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                    findNodeByText(latest, "Next")?.let { clickNodeOrParent(it) }
                }, 600L)
                return
            }
        }

        // 5c. Get your code from your authentication app -> Generate TOTP -> Enter -> Next
        if (!totpSubmitted &&
            twoFaKeyCaptured &&
            pageText.contains("Get your code from your authentication app", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val nextBtn = findNodeByText(nodes, "Next")
            if (edits.isNotEmpty() && nextBtn != null) {
                lastActionTimestamp = now
                totpSubmitted = true
                val waitMs = if (TotpHelper.secondsRemaining() < 5) 5500L else 200L
                if (waitMs > 1000L) {
                    AutomationState.log("Waiting ${waitMs / 1000}s for fresh TOTP timer...")
                }
                mainHandler.postDelayed({
                    if (!AutomationState.isRunning) return@postDelayed
                    val code = TotpHelper.generateTotp(AutomationState.currentTwoFa)
                    AutomationState.log("Generated 2FA TOTP: $code")
                    val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                    val latestEdits = findEditableNodes(latest)
                    if (latestEdits.isNotEmpty()) {
                        setTextOnNode(latestEdits.first(), code)
                        mainHandler.postDelayed({
                            val afterNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                            findNodeByText(afterNodes, "Next")?.let {
                                clickNodeOrParent(it)
                                AutomationState.log("Submitted 6-digit 2FA code.")
                            }
                        }, 700L)
                    }
                }, waitMs)
                return
            }
        }

        // 5d. Done screen
        if (pageText.contains("Your two-factor authentication has been set up", ignoreCase = true)) {
            lastActionTimestamp = now
            findNodeByText(nodes, "Done")?.let { clickNodeOrParent(it) }
            AutomationState.currentStep = AutomationState.Step.DONE
            AutomationState.updateStatus("Done! Saved Number, Pass & 2FA")
            AutomationState.log("2FA Setup Complete! Number, Password & 2FA Key saved in app.")
            saveCurrentRecord()
            AutomationState.isRunning = false
        }
    }

    private fun clickConfirmAndOpenAccountsCenter() {
        mainHandler.postDelayed({
            if (!AutomationState.isRunning) return@postDelayed
            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
            val confirmBtn = findNodeByText(latest, "Confirm") ?: findNodeByText(latest, "Continue")
            if (confirmBtn != null) {
                clickNodeOrParent(confirmBtn)
                AutomationState.log("Clicked Confirm on Name & DOB.")
            }
            if (!openedAccountsCenter) {
                openedAccountsCenter = true
                mainHandler.postDelayed({
                    if (!AutomationState.isRunning) return@postDelayed
                    AutomationState.currentStep = AutomationState.Step.ACCOUNTS_CENTER
                    AutomationState.updateStatus("Step 4: Opening Accounts Center")
                    AutomationState.log("Navigating to Accounts Center...")
                    AutomationState.openUrlInVia(this, AutomationState.URL_META_2FA)
                }, 3200L)
            }
        }, 700L)
    }

    private fun startOtpPolling() {
        if (!isPollingOtp.compareAndSet(false, true)) return
        AutomationState.updateStatus("Step 2: Polling GrabMail for OTP...")
        AutomationState.log("Waiting for 6-digit OTP at ${AutomationState.currentEmail}...")

        val apiKey = VaultManager.getGrabMailKey(this)
        val email = AutomationState.currentEmail

        Thread {
            try {
                var code: String? = null
                for (attempt in 1..24) {
                    if (!AutomationState.isRunning) break
                    code = GrabMailClient.fetchOtpCode(email, apiKey)
                    if (code != null) break
                    Thread.sleep(2500L)
                }

                mainHandler.post {
                    isPollingOtp.set(false)
                    if (code != null && AutomationState.isRunning) {
                        otpSubmitted = true
                        AutomationState.log("OTP Received: $code")
                        AutomationState.updateStatus("Step 2: Entering OTP $code")
                        val root = rootInActiveWindow ?: return@post
                        val nodes = collectAllNodes(root)
                        val edits = findEditableNodes(nodes)
                        if (edits.size >= 6) {
                            for (i in 0 until 6) {
                                setTextOnNode(edits[i], code[i].toString())
                            }
                        } else if (edits.isNotEmpty()) {
                            setTextOnNode(edits.first(), code)
                        }

                        mainHandler.postDelayed({
                            if (!AutomationState.isRunning) return@postDelayed
                            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                            val btn = findNodeByText(latest, "Confirm") ?: findNodeByText(latest, "Continue")
                            if (btn != null) {
                                clickNodeOrParent(btn)
                                AutomationState.log("Submitted OTP.")
                            }
                        }, 800L)
                    } else if (AutomationState.isRunning) {
                        AutomationState.log("OTP timed out. Tap Resend or check GrabMail.")
                        AutomationState.updateStatus("OTP Timeout - Waiting")
                    }
                }
            } catch (e: Exception) {
                isPollingOtp.set(false)
                AutomationState.log("OTP error: ${e.message}")
            }
        }.start()
    }

    private fun saveCurrentRecord() {
        val displayId = AutomationState.currentNumber.ifBlank { AutomationState.currentEmail }
        VaultManager.addOrUpdateRecord(
            this,
            AccountRecord(
                id = AutomationState.currentRecordId,
                numberOrEmail = displayId,
                password = AutomationState.currentPassword,
                twoFa = AutomationState.currentTwoFa
            )
        )
    }

    private fun resetFlags() {
        emailSubmitted = false
        otpSubmitted = false
        nameDobSubmitted = false
        passwordSubmitted = false
        openedAccountsCenter = false
        numberAdded = false
        emailDeleted = false
        twoFaKeyCaptured = false
        deviceNameSubmitted = false
        totpSubmitted = false
    }

    private fun collectAllNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            result.add(node)
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return result
    }

    private fun findEditableNodes(nodes: List<AccessibilityNodeInfo>): List<AccessibilityNodeInfo> {
        return nodes.filter {
            it.isEditable || (it.className?.toString()?.contains("EditText", ignoreCase = true) == true)
        }
    }

    private fun findNodeByText(nodes: List<AccessibilityNodeInfo>, query: String): AccessibilityNodeInfo? {
        return nodes.firstOrNull { node ->
            val t = node.text?.toString() ?: ""
            val d = node.contentDescription?.toString() ?: ""
            t.equals(query, ignoreCase = true) ||
                d.equals(query, ignoreCase = true) ||
                t.contains(query, ignoreCase = true)
        }
    }

    private fun setTextOnNode(node: AccessibilityNodeInfo, text: String) {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo) {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
            current = current.parent
        }
    }

    override fun onInterrupt() {
        AutomationState.stopSession()
    }
}
