package com.metaautocreator.app;

import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.Random;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class MetaAutomationEngine {

    public interface Callback {
        void onLog(String msg);
        boolean isRunning();
        double getSpeedMultiplier();
    }

    public static final String META_AI_URL = "https://www.meta.ai/";
    public static final String AUTH_URL = "https://auth.meta.com/?waterfall_id=2992ce49-32be-4fc5-8bb3-dc276e0a09bd&redirect_uri=https%3A%2F%2Fauth.meta.com%2Foidc%2F%3Fapp_id%3D1522763855472543%26redirect_uri%3Dhttps%253A%252F%252Fauth.meta.ai%252Fecto%26response_type%3Dcode%26scope%3Dopenid%252Blinking%26state%3DeyJjc3JmX3Rva2VuIjoidWVpN2EyNFhJY0xFR3h2UXEtY1lRUkhKOHZKR25FQ2luZ0htNk5UeGxZYyIsInJlZGlyZWN0X3RvIjoiaHR0cHM6Ly93d3cubWV0YS5haS9vaWRjL2NhbGxiYWNrIiwic3RhcnRlZF9hdCI6MTc5MTUzMTY0MzU5OSwid2F0ZXJmYWxsX2lkIjoiMjk5MmNlNDktMzJiZS00ZmM1LThiYjMtZGMyNzZlMGEwOWJkIn0%253D%26waterfall_id%3D2992ce49-32be-4fc5-8bb3-dc276e0a09bd%26code_challenge%3DSoV2XsXPO9EYS1aVS-aTlxbonOG6l5S8d0on4IfeWdU%26code_challenge_method%3DS256&source_app_id=1522763855472543&force_reauth=0";
    public static final String MUSE_URL = "https://muse.ai/?campaign_id=24452360397&extra_1=s%7Cc%7C831428651195%7Ce%7Cmuse+ai%7C&placement=&creative=831428651195&keyword=muse+ai&partner_id=googlesem";
    public static final String ACCOUNTS_CENTER_URL = "https://accountscenter.meta.com/";
    public static final String SECURITY_URL = "https://accountscenter.meta.com/password_and_security";
    public static final String CONTACT_URL = "https://accountscenter.meta.com/personal_info/contact_points";

    private static final String[] FIRST_NAMES = {
        "Rahim", "Karim", "Tanvir", "Tariq", "Nabil", "Arif", "Sadia", "Nadia",
        "Farhan", "Imran", "Mehedi", "Rashed", "Sajid", "Sumaiya", "Tania", "Nusrat"
    };
    private static final String[] LAST_NAMES = {
        "Ahmed", "Rahman", "Hasan", "Islam", "Khan", "Hossain", "Chowdhury", "Sarker",
        "Uddin", "Mia", "Akter", "Begum", "Ali", "Karim", "Mahmud", "Siddique"
    };

    private final WebView webView;
    private final Handler mainHandler;
    private final Callback cb;
    private final Random random = new Random();
    private String lastTwoFaKey = "N/A";

    public MetaAutomationEngine(WebView webView, Handler mainHandler, Callback cb) {
        this.webView = webView;
        this.mainHandler = mainHandler;
        this.cb = cb;
    }

    public String getLastTwoFaKey() {
        return lastTwoFaKey;
    }

    private void smartSleep(long ms) throws Exception {
        double mult = cb.getSpeedMultiplier();
        long adj = (long) (ms / mult);
        if (ms >= 500 && mult > 1.0) adj = Math.max(150, adj);
        long end = System.currentTimeMillis() + adj;
        while (System.currentTimeMillis() < end) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            Thread.sleep(100);
        }
    }

    public void clearWebViewDataSync() {
        CountDownLatch latch = new CountDownLatch(1);
        mainHandler.post(() -> {
            try {
                CookieManager cm = CookieManager.getInstance();
                cm.removeAllCookies(null);
                cm.flush();
                WebStorage.getInstance().deleteAllData();
                webView.clearCache(true);
                webView.clearHistory();
                webView.loadUrl("about:blank");
            } catch (Exception ignored) {
            }
            latch.countDown();
        });
        try {
            latch.await(4, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
    }

    private void loadUrlSync(String url) throws Exception {
        mainHandler.post(() -> webView.loadUrl(url));
        smartSleep(2500);
        for (int i = 0; i < 20; i++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String state = evalJs("return document.readyState;");
            if ("complete".equals(state)) break;
            smartSleep(400);
        }
    }

    private String evalJs(String body) {
        if (!cb.isRunning()) return "";
        AtomicReference<String> res = new AtomicReference<>("");
        CountDownLatch latch = new CountDownLatch(1);
        mainHandler.post(() -> webView.evaluateJavascript("(function(){" + body + "})()", value -> {
            if (value != null && !"null".equals(value)) {
                try {
                    if (value.startsWith("\"") && value.endsWith("\"")) {
                        res.set(new JSONObject("{\"v\":" + value + "}").optString("v", ""));
                    } else {
                        res.set(value);
                    }
                } catch (Exception e) {
                    res.set(value);
                }
            }
            latch.countDown();
        }));
        try {
            latch.await(8, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return res.get();
    }

    private boolean handleCookiesAndAccessDenied(int[] okCount) throws Exception {
        String lower = evalJs("return (document.body ? document.body.innerText : '').toLowerCase();");
        if (lower.contains("allow all cookies") || lower.contains("allow the use of cookies")) {
            evalJs("var bs=document.querySelectorAll('button,[role=button],span');for(var i=bs.length-1;i>=0;i--){if((bs[i].innerText||'').trim().toLowerCase()==='allow all cookies'){bs[i].click();return '1';}}return '0';");
            smartSleep(1500);
        }
        if (lower.contains("access denied") || lower.contains("not allowed to access this page") || lower.contains("something went wrong")) {
            if (okCount[0] < 3) {
                evalJs("var bs=document.querySelectorAll('button,[role=button],span');for(var i=bs.length-1;i>=0;i--){if((bs[i].innerText||'').trim()==='OK'){bs[i].click();return '1';}}return '0';");
                okCount[0]++;
                cb.onLog("Alert -> clicked OK (" + okCount[0] + "/3)");
                smartSleep(1500);
                return true;
            }
        }
        return false;
    }

    private boolean clickByTextJs(String targetText, int timeoutSec) throws Exception {
        long end = System.currentTimeMillis() + (timeoutSec * 1000L);
        String safe = targetText.replace("'", "\\'");
        while (System.currentTimeMillis() < end) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String clicked = evalJs(
                "var t='" + safe + "';" +
                "var els=document.querySelectorAll('button,[role=button],a,span,div,[role=option],[role=menuitem]');" +
                "for(var i=els.length-1;i>=0;i--){" +
                "  var el=els[i];" +
                "  if(!el.offsetParent && el.tagName!=='BODY') continue;" +
                "  if((el.innerText||'').trim()===t){" +
                "    var anc=el.closest('button,[role=button],a,[role=option],[role=menuitem]')||el;" +
                "    anc.scrollIntoView({block:'center'});" +
                "    anc.click();" +
                "    return '1';" +
                "  }" +
                "}return '0';"
            );
            if ("1".equals(clicked)) return true;
            smartSleep(400);
        }
        return false;
    }

    private boolean selectMuseDropdownByLabel(String fieldLabel, String optionText) throws Exception {
        String safeLabel = fieldLabel.replace("'", "\\'");
        String safeOpt = optionText.replace("'", "\\'");
        // Click the dropdown button that contains fieldLabel (Month, Day, Year)
        String opened = evalJs(
            "var lbl='" + safeLabel + "';" +
            "var els=document.querySelectorAll('button,[role=combobox],[role=button],div');" +
            "for(var i=els.length-1;i>=0;i--){" +
            "  var el=els[i];" +
            "  if(!el.offsetParent) continue;" +
            "  var t=(el.innerText||'').trim();" +
            "  if(t.indexOf(lbl)===0 || t.indexOf('\\n')!==-1 && t.split('\\n')[0].trim()===lbl){" +
            "    el.scrollIntoView({block:'center'}); el.click(); return '1';" +
            "  }" +
            "}" +
            "return '0';"
        );
        if (!"1".equals(opened)) {
            if (!clickByTextJs(fieldLabel, 6)) return false;
        }
        smartSleep(800);

        for (int s = 0; s < 36; s++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String clicked = evalJs(
                "var t='" + safeOpt + "';" +
                "var els=document.querySelectorAll('[role=option],[role=menuitem],div,span,li,button');" +
                "for(var i=els.length-1;i>=0;i--){" +
                "  var el=els[i];" +
                "  if(!el.offsetParent) continue;" +
                "  if((el.innerText||'').trim()===t){" +
                "    el.scrollIntoView({block:'center'});" +
                "    el.click();" +
                "    return '1';" +
                "  }" +
                "}" +
                "var scs=Array.from(document.querySelectorAll('[role=listbox],[role=menu],div,ul')).filter(d=>d.offsetParent && d.scrollHeight>d.clientHeight+10 && d.clientHeight<600);" +
                "for(var k=scs.length-1;k>=0;k--){ scs[k].scrollTop += 280; }" +
                "return '0';"
            );
            if ("1".equals(clicked)) {
                smartSleep(600);
                return true;
            }
            smartSleep(250);
        }
        return false;
    }

    private boolean setInputValueJs(String cssSelector, String val) {
        String safeVal = val.replace("\\", "\\\\").replace("'", "\\'");
        String res = evalJs(
            "var inp=document.querySelector(\"" + cssSelector + "\");" +
            "if(!inp) return '0';" +
            "inp.scrollIntoView({block:'center'}); inp.focus();" +
            "var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;" +
            "setter.call(inp,'" + safeVal + "');" +
            "inp.dispatchEvent(new Event('input',{bubbles:true}));" +
            "inp.dispatchEvent(new Event('change',{bubbles:true}));" +
            "inp.dispatchEvent(new Event('blur',{bubbles:true}));" +
            "return '1';"
        );
        return "1".equals(res);
    }

    private boolean setOtpSmartJs(String otp) {
        String safeOtp = otp.replace("\\", "\\\\").replace("'", "\\'");
        String res = evalJs(
            "var otp='" + safeOtp + "';" +
            "var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;" +
            "var pins=Array.from(document.querySelectorAll('input[data-slot=\"pin-digit\"],input[maxlength=\"1\"]'));" +
            "if(pins.length>=6){" +
            "  for(var i=0;i<6&&i<otp.length;i++){" +
            "    pins[i].focus();" +
            "    setter.call(pins[i],otp[i]);" +
            "    pins[i].dispatchEvent(new Event('input',{bubbles:true}));" +
            "    pins[i].dispatchEvent(new Event('change',{bubbles:true}));" +
            "  }" +
            "  return '6';" +
            "}" +
            "var single=document.querySelector('input[maxlength=\"6\"],input[autocomplete=\"one-time-code\"],input[inputmode=\"numeric\"],input[type=\"tel\"],input');" +
            "if(!single) return '0';" +
            "single.focus();" +
            "setter.call(single,otp);" +
            "single.dispatchEvent(new Event('input',{bubbles:true}));" +
            "single.dispatchEvent(new Event('change',{bubbles:true}));" +
            "return '1';"
        );
        return !"0".equals(res) && !res.isEmpty();
    }

    private String generateBd10DigitPhone() {
        String[] prefixes = {"13", "14", "15", "16", "17", "18", "19"};
        StringBuilder sb = new StringBuilder(prefixes[random.nextInt(prefixes.length)]);
        for (int i = 0; i < 8; i++) sb.append(random.nextInt(10));
        return sb.toString();
    }

    private void selectBangladeshCountryAndSave() throws Exception {
        String body = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
        if (body.contains("bangladesh (+880)")) return;
        evalJs("var els=document.querySelectorAll('div,span,button,a');for(var i=els.length-1;i>=0;i--){var t=(els[i].innerText||'').trim();if(t==='Change'||t.indexOf('(+')!==-1){els[i].click();return '1';}}return '0';");
        smartSleep(1500);
        for (int i = 0; i < 15; i++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String found = evalJs(
                "var els=document.querySelectorAll('div,span');" +
                "for(var i=0;i<els.length;i++){" +
                "  if((els[i].innerText||'').trim()==='Bangladesh (+880)'){" +
                "    els[i].scrollIntoView({block:'center'}); els[i].click(); return '1';" +
                "  }" +
                "}" +
                "var dlg=document.querySelector('div[role=dialog]');" +
                "if(dlg){var sc=Array.from(dlg.querySelectorAll('div')).find(d=>d.scrollHeight>d.clientHeight+20);if(sc)sc.scrollTop+=350;}" +
                "return '0';"
            );
            if ("1".equals(found)) {
                smartSleep(1000);
                clickByTextJs("Save", 8);
                smartSleep(1500);
                return;
            }
            smartSleep(400);
        }
    }

    public String executeCreateMetaAccount(MailApiHelper.MailAccount mail, String mailProvider, String pwd, boolean useMuseAi, boolean with2fa) throws Exception {
        lastTwoFaKey = "N/A";
        int[] okCount = {0};

        // 1. Open muse.ai FIRST
        Set<String> oldMsgIds = MailApiHelper.getExistingMessageIds(mailProvider, mail.ref);
        boolean museOtpScreen = false;
        for (int t = 0; t < 3; t++) {
            cb.onLog("Opening muse.ai (try " + (t + 1) + ")...");
            loadUrlSync(MUSE_URL);
            smartSleep(2000);
            handleCookiesAndAccessDenied(okCount);

            boolean inputFound = false;
            for (int w = 0; w < 10; w++) {
                if (!cb.isRunning()) throw new Exception("Stopped by user");
                String hasInput = evalJs("return document.querySelector(\"input[inputmode='email'],input[data-slot='input'],input[type='email'],input\") ? '1' : '0';");
                if ("1".equals(hasInput)) {
                    inputFound = true;
                    break;
                }
                clickByTextJs("Use phone or email", 1);
                smartSleep(1000);
            }
            if (!inputFound) continue;

            cb.onLog("Entering email on muse.ai: " + mail.email);
            if (!setInputValueJs("input[inputmode='email'],input[data-slot='input'],input[type='email'],input", mail.email)) continue;
            smartSleep(1000);
            oldMsgIds = MailApiHelper.getExistingMessageIds(mailProvider, mail.ref);
            if (!clickByTextJs("Continue", 10)) continue;

            cb.onLog("Waiting for muse.ai 6-digit code screen...");
            for (int p = 0; p < 15; p++) {
                if (!cb.isRunning()) throw new Exception("Stopped by user");
                smartSleep(1000);
                handleCookiesAndAccessDenied(okCount);
                String hasPin = evalJs(
                    "if(document.querySelector('[data-slot=pin-digit],input[maxlength=\"6\"],input[autocomplete=\"one-time-code\"],input[inputmode=\"numeric\"]')) return '1';" +
                    "if(document.querySelectorAll('input[maxlength=\"1\"]').length>=6) return '1';" +
                    "var txt=(document.body?document.body.innerText:'').toLowerCase();" +
                    "if(txt.indexOf('enter your code')!==-1||txt.indexOf('6-digit code')!==-1) return '1';" +
                    "return '0';"
                );
                if ("1".equals(hasPin)) {
                    museOtpScreen = true;
                    break;
                }
            }
            if (museOtpScreen) break;
        }
        if (!museOtpScreen) throw new Exception("muse.ai code screen failed");

        // 2. Fetch NEW OTP & Confirm
        cb.onLog("Fetching NEW OTP from " + mailProvider + "...");
        String otp = null;
        for (int i = 0; i < 15; i++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            otp = MailApiHelper.fetchNewOtp(mailProvider, mail.ref, oldMsgIds);
            if (otp != null) break;
            smartSleep(3000);
        }
        if (otp == null) throw new Exception("Muse OTP timeout");

        cb.onLog("Entering Muse OTP: " + otp);
        setOtpSmartJs(otp);
        smartSleep(1200);
        if (!clickByTextJs("Confirm", 5)) clickByTextJs("Continue", 3);
        smartSleep(4000);

        // 3. Finish creating your account: Random First Name, Last Name, Month, Day, Year -> Confirm
        cb.onLog("Waiting for Finish creating your account...");
        boolean finishScreen = false;
        for (int w = 0; w < 12; w++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String bodyLow = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
            if (bodyLow.contains("finish creating your account") || bodyLow.contains("first name")) {
                finishScreen = true;
                break;
            }
            smartSleep(1000);
        }
        if (!finishScreen) throw new Exception("Finish creating account screen not shown");

        String fName = FIRST_NAMES[random.nextInt(FIRST_NAMES.length)];
        String lName = LAST_NAMES[random.nextInt(LAST_NAMES.length)];
        cb.onLog("Filling Name: " + fName + " " + lName);
        if (!setInputValueJs("input[placeholder*='First' i],input[aria-label*='First' i],input[name*='first' i]", fName)) {
            evalJs("var inps=document.querySelectorAll('input');if(inps.length>=1){var s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(inps[0],'" + fName + "');inps[0].dispatchEvent(new Event('input',{bubbles:true}));}");
        }
        smartSleep(500);
        if (!setInputValueJs("input[placeholder*='Last' i],input[aria-label*='Last' i],input[name*='last' i]", lName)) {
            evalJs("var inps=document.querySelectorAll('input');if(inps.length>=2){var s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(inps[1],'" + lName + "');inps[1].dispatchEvent(new Event('input',{bubbles:true}));}");
        }
        smartSleep(800);

        String[] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
        String month = months[random.nextInt(months.length)];
        int day = 1 + random.nextInt(28);
        int year = 1995 + random.nextInt(8); // 1995..2002 (fast scroll from 2026)
        cb.onLog("Selecting DOB: " + month + " " + day + ", " + year);

        selectMuseDropdownByLabel("Month", month);
        selectMuseDropdownByLabel("Day", String.valueOf(day));
        boolean yrOk = selectMuseDropdownByLabel("Year", String.valueOf(year));
        if (!yrOk) {
            selectMuseDropdownByLabel("Year", "2000");
        }
        smartSleep(1000);

        clickByTextJs("Confirm", 10);
        smartSleep(5000);

        for (int w = 0; w < 8; w++) {
            String pLow = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
            if (pLow.contains("waitlist") || pLow.contains("isn't available")) break;
            smartSleep(1000);
        }

        // 4. Go directly to https://www.meta.ai/ so Meta auto-authenticates
        cb.onLog("Opening meta.ai for auto-login...");
        loadUrlSync(META_AI_URL);
        smartSleep(3500);
        handleCookiesAndAccessDenied(okCount);

        // 5. Open https://accountscenter.meta.com/password_and_security
        cb.onLog("Opening Accounts Center...");
        loadUrlSync(SECURITY_URL);
        smartSleep(2500);
        handleCookiesAndAccessDenied(okCount);

        // If redirected to login, login with email + OTP
        String acLow = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
        if (acLow.contains("use mobile number or email") || acLow.contains("log in or create an account")) {
            cb.onLog("Logging into Accounts Center with email...");
            if (!clickByTextJs("Use mobile number or email address", 10)) clickByTextJs("Use mobile number or email", 4);
            smartSleep(1500);
            setInputValueJs("input", mail.email);
            smartSleep(1000);
            oldMsgIds = MailApiHelper.getExistingMessageIds(mailProvider, mail.ref);
            clickByTextJs("Continue", 10);
            smartSleep(4000);
            handleCookiesAndAccessDenied(okCount);

            String otpLogin = null;
            for (int i = 0; i < 12; i++) {
                if (!cb.isRunning()) throw new Exception("Stopped by user");
                otpLogin = MailApiHelper.fetchNewOtp(mailProvider, mail.ref, oldMsgIds);
                if (otpLogin != null) break;
                smartSleep(2500);
            }
            if (otpLogin != null) {
                cb.onLog("Entering Login OTP: " + otpLogin);
                setOtpSmartJs(otpLogin);
                smartSleep(1200);
                if (!clickByTextJs("Continue", 5)) clickByTextJs("Confirm", 4);
                smartSleep(4000);
            }
            loadUrlSync(SECURITY_URL);
            smartSleep(2000);
        }

        // 6. Two-factor authentication -> SMS -> Bangladesh (+880) + Save -> 10-digit -> Next -> X
        clickByTextJs("Two-factor authentication", 15);
        smartSleep(2500);
        clickByTextJs("Get started", 12);
        smartSleep(2000);

        evalJs("var r=document.querySelector(\"input[type='radio'][value='SMS']\");if(r){r.click();}else{var rs=document.querySelectorAll(\"input[type='radio']\");if(rs.length>1)rs[1].click();}");
        smartSleep(1000);
        clickByTextJs("Continue", 12);
        smartSleep(2500);

        selectBangladeshCountryAndSave();
        smartSleep(1500);
        String bd10 = generateBd10DigitPhone();
        cb.onLog("Entering BD 10-digit: " + bd10);
        setInputValueJs("input[type='tel'],input[autocomplete='tel-national'],input", bd10);
        smartSleep(1500);
        clickByTextJs("Next", 12);
        smartSleep(3500);

        // 7. Contact info -> Add mobile number -> Bangladesh (+880) + Save -> same bd10 -> Next
        cb.onLog("Adding Contact Info...");
        loadUrlSync(CONTACT_URL);
        handleCookiesAndAccessDenied(okCount);
        clickByTextJs("Add new contact info", 12);
        smartSleep(2000);
        clickByTextJs("Add mobile number", 12);
        smartSleep(2000);
        selectBangladeshCountryAndSave();
        setInputValueJs("input[type='tel'],input[autocomplete='tel-national'],input", bd10);
        smartSleep(1000);
        clickByTextJs("Next", 12);
        smartSleep(3500);

        // 8. Delete temp email
        cb.onLog("Deleting temp email...");
        loadUrlSync(CONTACT_URL);
        evalJs("var els=document.querySelectorAll('div,span');for(var i=0;i<els.length;i++){if((els[i].innerText||'').indexOf('" + mail.email + "')!==-1){els[i].click();return '1';}}return '0';");
        smartSleep(2500);
        clickByTextJs("Delete email address", 12);
        smartSleep(2000);
        clickByTextJs("Delete", 12);
        smartSleep(3000);
        if ("1".equals(evalJs("return document.querySelector(\"input[type='password']\")?'1':'0';"))) {
            setInputValueJs("input[type='password']", pwd);
            smartSleep(1000);
            clickByTextJs("Continue", 12);
            smartSleep(4000);
        }

        // 9. If Create Meta With 2FA is checked, setup Authenticator App 2FA directly in this logged-in session!
        if (with2fa) {
            cb.onLog("Setting up Authenticator App 2FA...");
            lastTwoFaKey = setupAuthApp2faInCurrentSession();
        }

        return "880" + bd10;
    }

    private String setupAuthApp2faInCurrentSession() throws Exception {
        loadUrlSync(SECURITY_URL);
        smartSleep(2000);
        clickByTextJs("Two-factor authentication", 15);
        smartSleep(2500);
        clickByTextJs("Get started", 12);
        smartSleep(2000);
        evalJs("var r=document.querySelectorAll(\"input[type='radio']\");if(r.length>0&&!r[0].checked)r[0].click();");
        smartSleep(800);
        clickByTextJs("Continue", 12);
        smartSleep(2500);

        String twoFaKey = evalJs(
            "var dlg=document.querySelector('div[role=dialog]');" +
            "var txt=dlg?dlg.innerText:(document.body?document.body.innerText:'');" +
            "var lines=txt.split(/\\r?\\n/);" +
            "for(var i=0;i<lines.length;i++){" +
            "  var c=lines[i].replace(/\\s+/g,'').toUpperCase();" +
            "  if(c.length>=16 && c.length<=64 && /^[A-Z2-7]+$/.test(c) && /[2-7]/.test(c)) return c;" +
            "}return '';"
        );
        if (twoFaKey.isEmpty()) throw new Exception("2FA key not found");

        if (!clickByTextJs("Enter code", 8)) clickByTextJs("Continue", 5);
        smartSleep(2000);

        String hasName = evalJs("var inp=document.querySelector(\"input[type='text']:not([maxlength='6'])\");return inp?'1':'0';");
        if ("1".equals(hasName)) {
            setInputValueJs("input[type='text']:not([maxlength='6'])", "MetaAuth" + (100 + random.nextInt(900)));
            smartSleep(800);
            clickByTextJs("Next", 10);
            smartSleep(2500);
        }

        int rem = TotpHelper.getRemainingSeconds();
        if (rem < 5) smartSleep((rem + 1) * 1000L);
        String totp = TotpHelper.generateTotp(twoFaKey);

        cb.onLog("Entering built-in 2FA TOTP: " + totp);
        setOtpSmartJs(totp);
        smartSleep(1000);
        if (!clickByTextJs("Next", 8)) clickByTextJs("Continue", 5);
        smartSleep(3000);
        clickByTextJs("Done", 12);
        smartSleep(2000);

        return twoFaKey;
    }

    public String execute2faForNumber(String number, String pwd) throws Exception {
        int[] okCount = {0};
        cb.onLog("2FA Login: " + number);
        loadUrlSync(SECURITY_URL);
        handleCookiesAndAccessDenied(okCount);

        String pLow = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
        if (pLow.contains("use mobile number or email")) {
            clickByTextJs("Use mobile number or email address", 12);
            smartSleep(2000);
            setInputValueJs("input[autocomplete='username'],input[type='text']", number);
            smartSleep(1000);
            clickByTextJs("Continue", 12);
            smartSleep(3500);
            clickByTextJs("Enter password instead", 12);
            smartSleep(2000);
            setInputValueJs("input[type='password']", pwd);
            smartSleep(1000);
            clickByTextJs("Continue", 12);
            smartSleep(4500);
            loadUrlSync(SECURITY_URL);
        }

        return setupAuthApp2faInCurrentSession();
    }
}
