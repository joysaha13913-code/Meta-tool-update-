package com.joy.viaauto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var dotView: View? = null
    private var windowView: View? = null
    private lateinit var dotParams: WindowManager.LayoutParams
    private lateinit var windowParams: WindowManager.LayoutParams
    private var isWindowExpanded = false

    companion object {
        private const val CHANNEL_ID = "via_auto_overlay_channel"
        private const val NOTIF_ID = 101

        fun start(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingOverlayService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupDotOverlay()
        setupWindowOverlay()
        AutomationState.setListener { updateOverlayUi() }
        updateOverlayUi()
    }

    private fun setupDotOverlay() {
        dotView = LayoutInflater.from(this).inflate(R.layout.overlay_floating_dot, null)
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        dotParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 260
        }

        val tvDot = dotView!!.findViewById<TextView>(R.id.tvFloatingDot)
        attachDragAndClick(tvDot, dotParams, dotView!!) {
            toggleWindow(true)
        }
        windowManager.addView(dotView, dotParams)
    }

    private fun setupWindowOverlay() {
        windowView = LayoutInflater.from(this).inflate(R.layout.overlay_floating_window, null)
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 180
        }

        val header = windowView!!.findViewById<View>(R.id.llWindowHeader)
        attachDragAndClick(header, windowParams, windowView!!, null)

        windowView!!.findViewById<Button>(R.id.btnMinimizeWindow).setOnClickListener {
            toggleWindow(false)
        }

        windowView!!.findViewById<Button>(R.id.btnOverlayStop).setOnClickListener {
            AutomationState.stopSession()
            updateOverlayUi()
        }

        windowView!!.findViewById<Button>(R.id.btnOverlay2fa).setOnClickListener {
            AutomationState.log("Opening Meta Accounts Center 2FA...")
            AutomationState.openUrlInVia(this, AutomationState.URL_META_2FA)
        }

        windowView!!.visibility = View.GONE
        windowManager.addView(windowView, windowParams)
    }

    private fun toggleWindow(expand: Boolean) {
        isWindowExpanded = expand
        dotView?.visibility = if (expand) View.GONE else View.VISIBLE
        windowView?.visibility = if (expand) View.VISIBLE else View.GONE
        updateOverlayUi()
    }

    private fun updateOverlayUi() {
        val wv = windowView ?: return
        val tvTitle = wv.findViewById<TextView>(R.id.tvWindowTitle)
        val tvStep = wv.findViewById<TextView>(R.id.tvCurrentStep)
        val tvLog = wv.findViewById<TextView>(R.id.tvLiveLog)
        val svLog = wv.findViewById<ScrollView>(R.id.svLog)
        val tvDot = dotView?.findViewById<TextView>(R.id.tvFloatingDot)

        tvTitle.text = if (AutomationState.isRunning) "Via Auto • Running" else "Via Auto • Stopped"
        tvDot?.text = if (AutomationState.isRunning) "●" else "■"
        tvStep.text = AutomationState.statusText
        tvLog.text = AutomationState.getLogText()
        svLog.post { svLog.fullScroll(View.FOCUS_DOWN) }
    }

    private fun attachDragAndClick(
        touchTarget: View,
        params: WindowManager.LayoutParams,
        rootView: View,
        onClick: (() -> Unit)?
    ) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        touchTarget.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        moved = true
                    }
                    params.x = initialX + dx
                    params.y = initialY + dy
                    try {
                        windowManager.updateViewLayout(rootView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        onClick?.invoke()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Via Auto Assistant Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Via Auto Assistant")
            .setContentText("Floating control dot is active")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        AutomationState.setListener(null)
        try {
            dotView?.let { windowManager.removeView(it) }
            windowView?.let { windowManager.removeView(it) }
        } catch (_: Exception) {
        }
    }
}
