package com.joy.viaauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicBoolean

class ViaAutomationService : AccessibilityService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val isPollingOtp = AtomicBoolean(false)
    private var lastActionTimestamp = 0L

    private var lastSessionId = ""
    private var emailSubmitted = false
    private var otpSubmitted = false
    private var nameDobSubmitted = false
    private var passwordSubmitted = false
    private var openedAccountsCenter = false

    private var numberAdded = false
    private var emailDeleted = false
    private var twoFaKeyCaptured = false
    private var deviceNameSubmitted = false
    private var totpSubmitted = false
    private var browserCleaned = false

    private val firstNames = listOf("Rashed", "Tariq", "Arif", "Nabil", "Sajib", "Kamrul", "Hasan", "Imran", "Farhan", "Mahmud")
    private val lastNames = listOf("Mia", "Ahmed", "Rahman", "Islam", "Khan", "Hossain", "Chowdhury", "Sarkar")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !AutomationState.isRunning) return
        val pkg = event.packageName?.toString() ?: ""
        if (pkg != "mark.via.gp" && pkg != "mark.via") return

        if (lastSessionId != AutomationState.currentRecordId) {
            lastSessionId = AutomationState.currentRecordId
            resetFlags()
        }

        val now = System.currentTimeMillis()
        if (now - lastActionTimestamp < 1100L) return

        val root = rootInActiveWindow ?: return
        val nodes = collectAllNodes(root)
        if (nodes.isEmpty()) return

        val pageText = nodes.mapNotNull {
            val t = it.text?.toString() ?: ""
            val d = it.contentDescription?.toString() ?: ""
            "$t $d".trim()
        }.joinToString(" | ")

        // 1. Email Entry on muse.ai/?aymh_complete=1
        if (!emailSubmitted &&
            (pageText.contains("Log in or create an account", ignoreCase = true) ||
             pageText.contains("Mobile number or email", ignoreCase = true)) &&
            !pageText.contains("Enter your code", ignoreCase = true) &&
            !pageText.contains("Finish creating your account", ignoreCase = true) &&
            !pageText.contains("Login and security", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val continueBtn = findNodeByText(nodes, "Continue")
            if (edits.isNotEmpty() && continueBtn != null) {
                lastActionTimestamp = now
                emailSubmitted = true

                val email = GrabMailClient.generateRandomEmail()
                AutomationState.currentEmail = email
                AutomationState.currentStep = AutomationState.Step.WAIT_OTP
                AutomationState.updateStatus("Step 1: Entering $email")
                AutomationState.log("Generated GrabMail: $email")
                saveCurrentRecord()

                pasteTextOnNode(edits.first(), email) {
                    mainHandler.postDelayed({
                        if (AutomationState.isRunning) {
                            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                            findNodeByText(latest, "Continue")?.let {
                                tapNode(it)
                                AutomationState.log("Tapped Continue after email.")
                            }
                        }
                    }, 900L)
                }
                return
            }
        }

        // 2. 6-Digit OTP Verification
        if (!otpSubmitted &&
            (pageText.contains("Enter your code to sign up", ignoreCase = true) ||
             pageText.contains("6-digit code", ignoreCase = true))
        ) {
            if (!isPollingOtp.get() && AutomationState.currentEmail.isNotEmpty()) {
                lastActionTimestamp = now
                startOtpPolling()
            }
            return
        }

        // Optional Password Screen
        if (!passwordSubmitted &&
            pageText.contains("Password", ignoreCase = true) &&
            pageText.contains("Get started on Meta AI", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val continueBtn = findNodeByText(nodes, "Continue")
            if (edits.isNotEmpty() && continueBtn != null) {
                lastActionTimestamp = now
                passwordSubmitted = true
                pasteTextOnNode(edits.last(), AutomationState.currentPassword) {
                    AutomationState.log("Filled Password.")
                    saveCurrentRecord()
                    mainHandler.postDelayed({
                        if (AutomationState.isRunning) {
                            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                            findNodeByText(latest, "Continue")?.let { tapNode(it) }
                        }
                    }, 800L)
                }
                return
            }
        }

        // 3. Name & Date of Birth ("Finish creating your account")
        if (!nameDobSubmitted &&
            (pageText.contains("Finish creating your account", ignoreCase = true) ||
             (pageText.contains("First name", ignoreCase = true) && pageText.contains("Last name", ignoreCase = true)))
        ) {
            val edits = findEditableNodes(nodes)
            if (edits.size >= 2) {
                lastActionTimestamp = now
                nameDobSubmitted = true
                val fName = firstNames.random()
                val lName = lastNames.random()
                AutomationState.currentStep = AutomationState.Step.WAIT_NAME_DOB
                AutomationState.updateStatus("Step 3: Name ($fName $lName) & DOB")
                AutomationState.log("Filling Name: $fName $lName")

                pasteTextOnNode(edits[0], fName) {
                    mainHandler.postDelayed({
                        if (!AutomationState.isRunning) return@postDelayed
                        val latestEdits = rootInActiveWindow?.let { findEditableNodes(collectAllNodes(it)) } ?: emptyList()
                        val lastEdit = if (latestEdits.size >= 2) latestEdits[1] else edits[1]
                        pasteTextOnNode(lastEdit, lName) {
                            mainHandler.postDelayed({
                                selectAdultYearAndConfirm()
                            }, 700L)
                        }
                    }, 500L)
                }
                return
            }
        }

        // 4. Accounts Center: Add Number -> Delete Email -> Setup 2FA
        if (pageText.contains("Login and security", ignoreCase = true)) {
            if (!numberAdded || !emailDeleted) {
                findNodeByText(nodes, "Contact info")?.let {
                    lastActionTimestamp = now
                    AutomationState.updateStatus("Step 4: Opening Contact info")
                    tapNode(it)
                    AutomationState.log("Opened Contact info.")
                    return
                }
            } else if (!twoFaKeyCaptured) {
                findNodeByText(nodes, "Two-factor authentication")?.let {
                    lastActionTimestamp = now
                    AutomationState.updateStatus("Step 5: Opening 2FA Setup")
                    tapNode(it)
                    AutomationState.log("Opened Two-factor authentication.")
                    return
                }
            }
        }

        // 4b. Contact Info screen
        if (pageText.contains("Contact info", ignoreCase = true) &&
            pageText.contains("Add new contact info", ignoreCase = true)
        ) {
            if (!numberAdded && !pageText.contains("+880")) {
                findNodeByText(nodes, "Add new contact info")?.let {
                    lastActionTimestamp = now
                    tapNode(it)
                    AutomationState.log("Tapped Add new contact info.")
                    return
                }
            } else if (pageText.contains("+880") && !emailDeleted) {
                numberAdded = true
                val grabMailNode = nodes.firstOrNull {
                    (it.text?.toString() ?: "").contains("@grabmail.io", ignoreCase = true)
                }
                if (grabMailNode != null) {
                    lastActionTimestamp = now
                    tapNode(grabMailNode)
                    AutomationState.log("Selected temp email to delete.")
                    return
                } else {
                    emailDeleted = true
                }
            } else if (numberAdded && emailDeleted && !twoFaKeyCaptured) {
                lastActionTimestamp = now
                AutomationState.log("Number added & email deleted. Opening 2FA...")
                AutomationState.openUrlInVia(this, AutomationState.URL_META_2FA)
                return
            }
        }

        // 4c. "Add mobile number" option
        if (!numberAdded && pageText.contains("Add mobile number", ignoreCase = true) &&
            !pageText.contains("Enter mobile number", ignoreCase = true)
        ) {
            findNodeByText(nodes, "Add mobile number")?.let {
                lastActionTimestamp = now
                tapNode(it)
                AutomationState.log("Selected Add mobile number.")
                return
            }
        }

        // 4d. Enter mobile number screen ("Bangladesh (+880)" + "Enter mobile number")
        if (!numberAdded &&
            (pageText.contains("Enter mobile number", ignoreCase = true) ||
             pageText.contains("Add mobile number", ignoreCase = true)) &&
            pageText.contains("Next", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val nextBtn = findNodeByText(nodes, "Next")
            if (edits.isNotEmpty() && nextBtn != null) {
                lastActionTimestamp = now
                numberAdded = true
                val bd10 = AutomationState.generateRandomBdNumber10Digits()
                val fullNum = "0$bd10"
                AutomationState.currentNumber = fullNum
                AutomationState.updateStatus("Step 4: Adding Number $fullNum")
                AutomationState.log("Entering BD Number: $bd10 (saved as $fullNum)")
                saveCurrentRecord()

                pasteTextOnNode(edits.first(), bd10) {
                    mainHandler.postDelayed({
                        if (AutomationState.isRunning) {
                            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                            findNodeByText(latest, "Next")?.let {
                                tapNode(it)
                                AutomationState.log("Tapped Next after adding number.")
                            }
                        }
                    }, 900L)
                }
                return
            }
        }

        // 4e. Delete email address
        if (!emailDeleted && pageText.contains("Delete email address", ignoreCase = true)) {
            val deleteConfirm = findNodeByText(nodes, "Delete")
            val deleteEmailBtn = findNodeByText(nodes, "Delete email address")
            lastActionTimestamp = now
            if (pageText.contains("Delete email address?", ignoreCase = true) && deleteConfirm != null) {
                emailDeleted = true
                tapNode(deleteConfirm)
                AutomationState.log("Confirmed Delete email address.")
                return
            } else if (deleteEmailBtn != null) {
                tapNode(deleteEmailBtn)
                AutomationState.log("Tapped Delete email address.")
                return
            }
        }

        // 5. 2FA Setup Flow
        if (pageText.contains("Set up extra protection", ignoreCase = true)) {
            if (!numberAdded) {
                val closeBtn = findNodeByText(nodes, "Close") ?: nodes.firstOrNull {
                    (it.contentDescription?.toString() ?: "").contains("Close", ignoreCase = true)
                }
                if (closeBtn != null) {
                    lastActionTimestamp = now
                    tapNode(closeBtn)
                    AutomationState.log("Closed 2FA modal to add number first.")
                    return
                }
            } else {
                findNodeByText(nodes, "Get started")?.let {
                    lastActionTimestamp = now
                    tapNode(it)
                    AutomationState.log("Tapped Get started for 2FA.")
                    return
                }
            }
        }

        if (pageText.contains("Help protect your account", ignoreCase = true) &&
            pageText.contains("Authentication app", ignoreCase = true)
        ) {
            lastActionTimestamp = now
            findNodeByText(nodes, "Authentication app")?.let { tapNode(it) }
            mainHandler.postDelayed({
                val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                findNodeByText(latest, "Continue")?.let {
                    tapNode(it)
                    AutomationState.log("Selected Authentication app -> Continue.")
                }
            }, 700L)
            return
        }

        // 5a. Instructions for setup -> Capture Base32 Key & click Next
        if (!twoFaKeyCaptured &&
            pageText.contains("Instructions for setup", ignoreCase = true) &&
            pageText.contains("Copy key", ignoreCase = true)
        ) {
            val keyMatch = Regex("\\b([A-Z2-7]{4}(?:\\s+[A-Z2-7]{4}){3,7})\\b").find(pageText)
            val candidate = keyMatch?.groupValues?.getOrNull(1)?.replace(Regex("\\s+"), "") ?: ""
            if (candidate.length >= 16 && candidate != "LOGINANDSECURITY") {
                lastActionTimestamp = now
                twoFaKeyCaptured = true
                AutomationState.currentTwoFa = candidate
                AutomationState.updateStatus("Step 5: Captured 2FA Key")
                AutomationState.log("Captured 2FA Key: $candidate")
                saveCurrentRecord()

                findNodeByText(nodes, "Next")?.let {
                    tapNode(it)
                    AutomationState.log("Tapped Next after capturing 2FA key.")
                }
                return
            }
        }

        // 5b. Connect device -> Enter device name -> Next
        if (!deviceNameSubmitted &&
            pageText.contains("Connect device", ignoreCase = true) &&
            pageText.contains("Name", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val nextBtn = findNodeByText(nodes, "Next")
            if (edits.isNotEmpty() && nextBtn != null) {
                lastActionTimestamp = now
                deviceNameSubmitted = true
                pasteTextOnNode(edits.first(), "Device1") {
                    AutomationState.log("Entered device name: Device1")
                    mainHandler.postDelayed({
                        val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                        findNodeByText(latest, "Next")?.let { tapNode(it) }
                    }, 700L)
                }
                return
            }
        }

        // 5c. Enter 6-digit TOTP code -> Next
        if (!totpSubmitted &&
            twoFaKeyCaptured &&
            pageText.contains("Get your code from your authentication app", ignoreCase = true)
        ) {
            val edits = findEditableNodes(nodes)
            val nextBtn = findNodeByText(nodes, "Next")
            if (edits.isNotEmpty() && nextBtn != null) {
                lastActionTimestamp = now
                totpSubmitted = true
                val waitMs = if (TotpHelper.secondsRemaining() < 5) 5500L else 200L
                if (waitMs > 1000L) {
                    AutomationState.log("Waiting ${waitMs / 1000}s for fresh TOTP timer...")
                }
                mainHandler.postDelayed({
                    if (!AutomationState.isRunning) return@postDelayed
                    val code = TotpHelper.generateTotp(AutomationState.currentTwoFa)
                    AutomationState.log("Generated 2FA TOTP: $code")
                    val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                    val latestEdits = findEditableNodes(latest)
                    if (latestEdits.isNotEmpty()) {
                        pasteTextOnNode(latestEdits.first(), code) {
                            mainHandler.postDelayed({
                                val afterNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                                findNodeByText(afterNodes, "Next")?.let {
                                    tapNode(it)
                                    AutomationState.log("Submitted 6-digit 2FA code.")
                                }
                            }, 800L)
                        }
                    }
                }, waitMs)
                return
            }
        }

        // 5d. Done screen -> Save & Clean Via Browser
        if (!browserCleaned && pageText.contains("Your two-factor authentication has been set up", ignoreCase = true)) {
            lastActionTimestamp = now
            browserCleaned = true
            findNodeByText(nodes, "Done")?.let { tapNode(it) }
            AutomationState.currentStep = AutomationState.Step.DONE
            AutomationState.updateStatus("Done! Cleaning Via Browser...")
            AutomationState.log("2FA Setup Complete! Saved Number, Password & 2FA Key.")
            saveCurrentRecord()

            mainHandler.postDelayed({
                cleanViaBrowser()
            }, 1500L)
        }
    }

    private fun selectAdultYearAndConfirm() {
        if (!AutomationState.isRunning) return
        val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
        val yearNode = findNodeByText(latest, "2026")
        if (yearNode != null) {
            tapNode(yearNode)
            AutomationState.log("Opened Year dropdown...")
            scrollYearListAndPick(0)
        } else {
            clickConfirmAndOpenAccountsCenter()
        }
    }

    private fun scrollYearListAndPick(attempt: Int) {
        if (!AutomationState.isRunning) return
        mainHandler.postDelayed({
            val popNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
            val adultYear = findNodeByText(popNodes, "1999")
                ?: findNodeByText(popNodes, "2000")
                ?: findNodeByText(popNodes, "1998")
                ?: findNodeByText(popNodes, "2001")
                ?: findNodeByText(popNodes, "1997")
                ?: findNodeByText(popNodes, "1996")

            if (adultYear != null) {
                tapNode(adultYear)
                AutomationState.log("Selected Year: ${adultYear.text}")
                mainHandler.postDelayed({ clickConfirmAndOpenAccountsCenter() }, 700L)
            } else if (attempt < 5) {
                // Swipe up on the year dropdown popup (bottom-right area) to scroll to 1998-2001
                val dm = resources.displayMetrics
                val x = dm.widthPixels * 0.78f
                val startY = dm.heightPixels * 0.78f
                val endY = dm.heightPixels * 0.45f
                swipeGesture(x, startY, x, endY, 320L) {
                    scrollYearListAndPick(attempt + 1)
                }
            } else {
                AutomationState.log("Year scroll limit reached; tapping Confirm...")
                clickConfirmAndOpenAccountsCenter()
            }
        }, 650L)
    }

    private fun clickConfirmAndOpenAccountsCenter() {
        mainHandler.postDelayed({
            if (!AutomationState.isRunning) return@postDelayed
            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
            val confirmBtn = findNodeByText(latest, "Confirm") ?: findNodeByText(latest, "Continue")
            if (confirmBtn != null) {
                tapNode(confirmBtn)
                AutomationState.log("Tapped Confirm on Name & DOB.")
            }
            if (!openedAccountsCenter) {
                openedAccountsCenter = true
                mainHandler.postDelayed({
                    if (!AutomationState.isRunning) return@postDelayed
                    AutomationState.currentStep = AutomationState.Step.ACCOUNTS_CENTER
                    AutomationState.updateStatus("Step 4: Opening Accounts Center")
                    AutomationState.log("Navigating to Accounts Center...")
                    AutomationState.openUrlInVia(this, AutomationState.URL_META_2FA)
                }, 3200L)
            }
        }, 700L)
    }

    private fun cleanViaBrowser() {
        AutomationState.log("Cleaning Via Browser tabs & session...")
        val nodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
        // Try Via Browser bottom-right Menu icon or Clear data / Close all tabs
        val menuNode = nodes.firstOrNull {
            val d = it.contentDescription?.toString() ?: ""
            d.contains("Menu", ignoreCase = true) || d.contains("More", ignoreCase = true)
        }
        if (menuNode != null) {
            tapNode(menuNode)
            mainHandler.postDelayed({
                val menuNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                val clearNode = findNodeByText(menuNodes, "Clear data")
                    ?: findNodeByText(menuNodes, "Exit")
                    ?: findNodeByText(menuNodes, "Settings")
                if (clearNode != null) {
                    tapNode(clearNode)
                    mainHandler.postDelayed({
                        val dlgNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                        val okBtn = findNodeByText(dlgNodes, "OK")
                            ?: findNodeByText(dlgNodes, "Clear")
                            ?: findNodeByText(dlgNodes, "Confirm")
                        okBtn?.let { tapNode(it) }
                        finishSessionCleaned()
                    }, 700L)
                } else {
                    finishSessionCleaned()
                }
            }, 700L)
        } else {
            // Fallback: tap bottom-right menu coordinate on Via Browser
            val dm = resources.displayMetrics
            tapPoint(dm.widthPixels * 0.90f, dm.heightPixels * 0.95f) {
                mainHandler.postDelayed({
                    val menuNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                    val clearNode = findNodeByText(menuNodes, "Clear data") ?: findNodeByText(menuNodes, "Exit")
                    if (clearNode != null) {
                        tapNode(clearNode)
                        mainHandler.postDelayed({
                            val dlgNodes = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
                            (findNodeByText(dlgNodes, "OK") ?: findNodeByText(dlgNodes, "Clear"))?.let { tapNode(it) }
                            finishSessionCleaned()
                        }, 700L)
                    } else {
                        finishSessionCleaned()
                    }
                }, 700L)
            }
        }
    }

    private fun finishSessionCleaned() {
        AutomationState.log("Via Browser cleaned. Task Complete!")
        AutomationState.updateStatus("Done! Via Browser Cleaned")
        AutomationState.isRunning = false
    }

    private fun startOtpPolling() {
        if (!isPollingOtp.compareAndSet(false, true)) return
        AutomationState.updateStatus("Step 2: Polling GrabMail for OTP...")
        AutomationState.log("Waiting for 6-digit OTP at ${AutomationState.currentEmail}...")

        val email = AutomationState.currentEmail
        Thread {
            try {
                var code: String? = null
                for (attempt in 1..24) {
                    if (!AutomationState.isRunning) break
                    code = GrabMailClient.fetchOtpCode(email, "")
                    if (code != null) break
                    Thread.sleep(2500L)
                }

                mainHandler.post {
                    isPollingOtp.set(false)
                    if (code != null && AutomationState.isRunning) {
                        otpSubmitted = true
                        AutomationState.log("OTP Received: $code")
                        AutomationState.updateStatus("Step 2: Entering OTP $code")
                        val root = rootInActiveWindow ?: return@post
                        val nodes = collectAllNodes(root)
                        val edits = findEditableNodes(nodes)
                        if (edits.size >= 6) {
                            for (i in 0 until 6) {
                                pasteTextOnNode(edits[i], code[i].toString()) {}
                            }
                            submitOtpAfterDelay()
                        } else if (edits.isNotEmpty()) {
                            pasteTextOnNode(edits.first(), code) {
                                submitOtpAfterDelay()
                            }
                        }
                    } else if (AutomationState.isRunning) {
                        AutomationState.log("OTP timed out. Tap Resend or check GrabMail.")
                        AutomationState.updateStatus("OTP Timeout - Waiting")
                    }
                }
            } catch (e: Exception) {
                isPollingOtp.set(false)
                AutomationState.log("OTP error: ${e.message}")
            }
        }.start()
    }

    private fun submitOtpAfterDelay() {
        mainHandler.postDelayed({
            if (!AutomationState.isRunning) return@postDelayed
            val latest = rootInActiveWindow?.let { collectAllNodes(it) } ?: emptyList()
            val btn = findNodeByText(latest, "Confirm") ?: findNodeByText(latest, "Continue")
            if (btn != null) {
                tapNode(btn)
                AutomationState.log("Submitted OTP.")
            }
        }, 900L)
    }

    private fun pasteTextOnNode(node: AccessibilityNodeInfo, text: String, onDone: () -> Unit) {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("input", text))

        val doPaste = {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val pasted = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            if (!pasted) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            mainHandler.postDelayed({ onDone() }, 250L)
        }

        if (!rect.isEmpty) {
            tapPoint(rect.exactCenterX(), rect.exactCenterY()) {
                mainHandler.postDelayed({ doPaste() }, 220L)
            }
        } else {
            doPaste()
        }
    }

    private fun tapNode(node: AccessibilityNodeInfo) {
        var current: AccessibilityNodeInfo? = node
        var clicked = false
        while (current != null) {
            if (current.isClickable) {
                clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (clicked) break
            }
            current = current.parent
        }
        if (!clicked) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty) {
                tapPoint(rect.exactCenterX(), rect.exactCenterY(), null)
            }
        }
    }

    private fun tapPoint(x: Float, y: Float, onComplete: (() -> Unit)?) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete?.invoke()
            }
        }, mainHandler)
    }

    private fun swipeGesture(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long, onComplete: () -> Unit) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete()
            }
        }, mainHandler)
    }

    private fun saveCurrentRecord() {
        val displayId = AutomationState.currentNumber.ifBlank { AutomationState.currentEmail }
        VaultManager.addOrUpdateRecord(
            this,
            AccountRecord(
                id = AutomationState.currentRecordId,
                numberOrEmail = displayId,
                password = AutomationState.currentPassword,
                twoFa = AutomationState.currentTwoFa
            )
        )
    }

    private fun resetFlags() {
        emailSubmitted = false
        otpSubmitted = false
        nameDobSubmitted = false
        passwordSubmitted = false
        openedAccountsCenter = false
        numberAdded = false
        emailDeleted = false
        twoFaKeyCaptured = false
        deviceNameSubmitted = false
        totpSubmitted = false
        browserCleaned = false
    }

    private fun collectAllNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            result.add(node)
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return result
    }

    private fun findEditableNodes(nodes: List<AccessibilityNodeInfo>): List<AccessibilityNodeInfo> {
        return nodes.filter {
            it.isEditable || (it.className?.toString()?.contains("EditText", ignoreCase = true) == true)
        }
    }

    private fun findNodeByText(nodes: List<AccessibilityNodeInfo>, query: String): AccessibilityNodeInfo? {
        return nodes.firstOrNull { node ->
            val t = node.text?.toString() ?: ""
            val d = node.contentDescription?.toString() ?: ""
            t.equals(query, ignoreCase = true) ||
                d.equals(query, ignoreCase = true) ||
                t.contains(query, ignoreCase = true)
        }
    }

    override fun onInterrupt() {
        AutomationState.stopSession()
    }
}
