package com.joy.viaauto

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object AutomationState {
    const val URL_MUSE_SIGNUP = "https://muse.ai/?aymh_complete=1"
    const val URL_META_2FA = "https://accountscenter.meta.com/password_and_security/two_factor"

    enum class Step {
        IDLE,
        WAIT_EMAIL_PAGE,
        WAIT_OTP,
        WAIT_NAME_DOB,
        ACCOUNTS_CENTER,
        DONE,
        STOPPED
    }

    @Volatile var isRunning: Boolean = false
    @Volatile var currentStep: Step = Step.IDLE
    @Volatile var currentRecordId: String = ""
    @Volatile var currentEmail: String = ""
    @Volatile var currentNumber: String = ""
    @Volatile var currentPassword: String = ""
    @Volatile var currentTwoFa: String = ""
    @Volatile var statusText: String = "Ready"

    private val logs = mutableListOf<String>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var listener: (() -> Unit)? = null

    fun setListener(l: (() -> Unit)?) {
        listener = l
    }

    fun startNewSession(context: Context) {
        val savedPass = VaultManager.getDefaultPassword(context)
        currentRecordId = UUID.randomUUID().toString()
        currentEmail = ""
        currentNumber = ""
        currentPassword = if (savedPass.isNotEmpty()) savedPass else generateRandomPassword()
        currentTwoFa = ""
        isRunning = true
        currentStep = Step.WAIT_EMAIL_PAGE
        synchronized(logs) { logs.clear() }
        log("Started session. Opening Via Browser...")
        updateStatus("Step 1: Muse signup")
    }

    fun stopSession() {
        isRunning = false
        currentStep = Step.STOPPED
        log("Automation stopped.")
        updateStatus("Stopped")
    }

    fun updateStatus(text: String) {
        statusText = text
        notifyListener()
    }

    fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        synchronized(logs) {
            logs.add("[$time] $message")
            if (logs.size > 50) {
                logs.removeAt(0)
            }
        }
        notifyListener()
    }

    fun getLogText(): String {
        synchronized(logs) {
            return if (logs.isEmpty()) "Waiting to start..." else logs.joinToString("\n")
        }
    }

    private fun notifyListener() {
        mainHandler.post { listener?.invoke() }
    }

    fun generateRandomPassword(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789@#!"
        return (1..12).map { chars.random() }.joinToString("")
    }

    fun generateRandomBdNumber10Digits(): String {
        val prefixes = listOf("17", "18", "19", "16", "13", "14", "15")
        val p = prefixes.random()
        val rest = (1..8).map { ('0'..'9').random() }.joinToString("")
        return "$p$rest"
    }

    fun openUrlInVia(context: Context, url: String) {
        val packages = listOf("mark.via.gp", "mark.via")
        for (pkg in packages) {
            try {
                val pm = context.packageManager
                pm.getPackageInfo(pkg, 0)
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
        try {
            val fallback = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        } catch (e: Exception) {
            log("Failed to open URL: ${e.message}")
        }
    }
}
