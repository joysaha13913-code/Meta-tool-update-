package com.joy.viaauto

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object GrabMailClient {
    private const val BASE_URL = "https://grabmail.io/api/v1"

    fun generateRandomEmail(): String {
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        val prefix = (1..10).map { chars.random() }.joinToString("")
        return "$prefix@grabmail.io"
    }

    fun fetchOtpCode(email: String, apiKey: String = ""): String? {
        try {
            val encodedEmail = URLEncoder.encode(email, "UTF-8")
            val mailboxUrl = "$BASE_URL/mailbox?address=$encodedEmail&limit=5"
            val mailboxJson = httpGet(mailboxUrl, apiKey) ?: return null
            val mailboxObj = JSONObject(mailboxJson)
            val messages = mailboxObj.optJSONArray("messages") ?: return null
            if (messages.length() == 0) return null

            for (i in 0 until messages.length()) {
                val msgSummary = messages.getJSONObject(i)
                val msgId = msgSummary.optString("id", "")
                val subject = msgSummary.optString("subject", "")
                extract6DigitCode(subject)?.let { return it }

                if (msgId.isNotEmpty()) {
                    val msgUrl = "$BASE_URL/message/$msgId?mailbox=$encodedEmail"
                    val msgJson = httpGet(msgUrl, apiKey) ?: continue
                    val msgObj = JSONObject(msgJson)
                    val text = msgObj.optString("text", "")
                    val html = msgObj.optString("html", "")
                    val fullSubject = msgObj.optString("subject", "")

                    extract6DigitCode(fullSubject)?.let { return it }
                    extract6DigitCode(text)?.let { return it }
                    extract6DigitCode(html)?.let { return it }
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun extract6DigitCode(content: String): String? {
        if (content.isBlank()) return null
        val regex = Regex("\\b(\\d{6})\\b")
        return regex.find(content)?.groupValues?.getOrNull(1)
    }

    private fun httpGet(urlStr: String, apiKey: String): String? {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            if (apiKey.isNotBlank()) {
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
        }
        return try {
            val code = conn.responseCode
            if (code in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            } else {
                null
            }
        } finally {
            conn.disconnect()
        }
    }
}
