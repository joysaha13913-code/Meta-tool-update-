package com.joy.viaauto

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class AccountRecord(
    val id: String = UUID.randomUUID().toString(),
    val numberOrEmail: String = "",
    val password: String = "",
    val twoFa: String = "",
    val timestamp: String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
)

object VaultManager {
    private const val PREFS_NAME = "via_auto_vault"
    private const val KEY_RECORDS = "saved_records"
    private const val KEY_DEFAULT_PASS = "default_password"
    private const val KEY_GRABMAIL_KEY = "grabmail_api_key"

    fun getRecords(context: Context): MutableList<AccountRecord> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_RECORDS, "[]") ?: "[]"
        val list = mutableListOf<AccountRecord>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    AccountRecord(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        numberOrEmail = obj.optString("numberOrEmail", ""),
                        password = obj.optString("password", ""),
                        twoFa = obj.optString("twoFa", ""),
                        timestamp = obj.optString("timestamp", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    private fun saveRecords(context: Context, list: List<AccountRecord>) {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("numberOrEmail", item.numberOrEmail)
                put("password", item.password)
                put("twoFa", item.twoFa)
                put("timestamp", item.timestamp)
            }
            arr.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_RECORDS, arr.toString())
            .apply()
    }

    fun addOrUpdateRecord(context: Context, record: AccountRecord) {
        val list = getRecords(context)
        val idx = list.indexOfFirst { it.id == record.id }
        if (idx >= 0) {
            list[idx] = record
        } else {
            list.add(0, record)
        }
        saveRecords(context, list)
    }

    fun deleteRecord(context: Context, id: String) {
        val list = getRecords(context).filterNot { it.id == id }
        saveRecords(context, list)
    }

    fun clearAll(context: Context) {
        saveRecords(context, emptyList())
    }

    fun saveSettings(context: Context, defaultPassword: String, grabMailKey: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_DEFAULT_PASS, defaultPassword.trim())
            .putString(KEY_GRABMAIL_KEY, grabMailKey.trim())
            .apply()
    }

    fun getDefaultPassword(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_DEFAULT_PASS, "") ?: ""
    }

    fun getGrabMailKey(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_GRABMAIL_KEY, "") ?: ""
    }
}
