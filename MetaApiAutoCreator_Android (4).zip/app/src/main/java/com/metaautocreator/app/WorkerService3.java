package com.metaautocreator.app;

public class WorkerService3 extends BaseWorkerService {
    @Override protected int getWorkerId() { return 3; }
}
