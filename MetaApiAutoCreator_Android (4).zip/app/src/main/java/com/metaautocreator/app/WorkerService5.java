package com.metaautocreator.app;

public class WorkerService5 extends BaseWorkerService {
    @Override protected int getWorkerId() { return 5; }
}
