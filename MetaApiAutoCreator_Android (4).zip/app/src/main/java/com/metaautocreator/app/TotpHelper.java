package com.metaautocreator.app;

import java.nio.ByteBuffer;
import java.util.Locale;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class TotpHelper {

    public static String cleanBase32(String secret) {
        if (secret == null) return "";
        return secret.toUpperCase(Locale.US).replaceAll("[^A-Z2-7]", "");
    }

    public static boolean isValidBase32Key(String secret) {
        String clean = cleanBase32(secret);
        return clean.length() >= 16 && clean.length() <= 64;
    }

    public static int getRemainingSeconds() {
        long sec = System.currentTimeMillis() / 1000L;
        return (int) (30 - (sec % 30));
    }

    public static String generateTotp(String secret) throws Exception {
        String clean = cleanBase32(secret);
        if (clean.length() < 8) {
            throw new IllegalArgumentException("Invalid 2FA key: " + secret);
        }
        byte[] keyBytes = decodeBase32(clean);
        long counter = (System.currentTimeMillis() / 1000L) / 30L;
        byte[] data = ByteBuffer.allocate(8).putLong(counter).array();

        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(keyBytes, "HmacSHA1"));
        byte[] hash = mac.doFinal(data);

        int offset = hash[hash.length - 1] & 0x0F;
        int binary = ((hash[offset] & 0x7F) << 24)
                | ((hash[offset + 1] & 0xFF) << 16)
                | ((hash[offset + 2] & 0xFF) << 8)
                | (hash[offset + 3] & 0xFF);
        int otp = binary % 1000000;
        return String.format(Locale.US, "%06d", otp);
    }

    private static byte[] decodeBase32(String base32) {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        ByteBuffer out = ByteBuffer.allocate((base32.length() * 5) / 8 + 1);
        int buffer = 0;
        int bitsLeft = 0;
        for (int i = 0; i < base32.length(); i++) {
            int val = alphabet.indexOf(base32.charAt(i));
            if (val < 0) continue;
            buffer = (buffer << 5) | val;
            bitsLeft += 5;
            if (bitsLeft >= 8) {
                bitsLeft -= 8;
                out.put((byte) ((buffer >> bitsLeft) & 0xFF));
            }
        }
        byte[] result = new byte[out.position()];
        out.flip();
        out.get(result);
        return result;
    }
}
