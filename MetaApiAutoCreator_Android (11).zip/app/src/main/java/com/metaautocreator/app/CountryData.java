package com.metaautocreator.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CountryData {

    public static class Country {
        public final String name;      // e.g. "Bangladesh (+880)"
        public final String dialCode;  // e.g. "880"
        public final int length;       // national digits length
        public final String[] prefixes;

        public Country(String name, String dialCode, int length, String... prefixes) {
            this.name = name;
            this.dialCode = dialCode;
            this.length = length;
            this.prefixes = prefixes;
        }

        public String generateNationalNumber(Random r) {
            String p = (prefixes != null && prefixes.length > 0) ? prefixes[r.nextInt(prefixes.length)] : "5";
            StringBuilder sb = new StringBuilder(p);
            while (sb.length() < length) {
                sb.append(r.nextInt(10));
            }
            if (sb.length() > length) return sb.substring(0, length);
            return sb.toString();
        }
    }

    private static final List<Country> COUNTRIES = new ArrayList<>();

    static {
        add("Bangladesh (+880)", "880", 10, "13", "14", "15", "16", "17", "18", "19");
        add("India (+91)", "91", 10, "62", "70", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99");
        add("Pakistan (+92)", "92", 10, "30", "31", "32", "33", "34");
        add("United States (+1)", "1", 10, "202", "212", "213", "305", "310", "312", "415", "646", "718", "818", "917");
        add("United Kingdom (+44)", "44", 10, "74", "75", "77", "78", "79");
        add("Brazil (+55)", "55", 11, "119", "219", "319", "419", "519", "619", "719", "819", "859", "919");
        add("Indonesia (+62)", "62", 10, "81", "82", "85", "87", "89");
        add("Vietnam (+84)", "84", 9, "32", "33", "34", "35", "56", "58", "70", "76", "77", "78", "79", "81", "82", "83", "84", "85", "86", "88", "89", "90", "91", "92", "93", "94", "96", "97", "98");
        add("Afghanistan (+93)", "93", 9, "70", "72", "74", "77", "78", "79");
        add("Albania (+355)", "355", 9, "67", "68", "69");
        add("Algeria (+213)", "213", 9, "5", "6", "7");
        add("American Samoa (+1)", "1", 10, "684");
        add("Andorra (+376)", "376", 6, "3", "6");
        add("Angola (+244)", "244", 9, "92", "93", "94");
        add("Anguilla (+1)", "1", 10, "264");
        add("Antigua and Barbuda (+1)", "1", 10, "268");
        add("Argentina (+54)", "54", 10, "911");
        add("Armenia (+374)", "374", 8, "91", "93", "94", "95", "96", "98", "99");
        add("Aruba (+297)", "297", 7, "56", "59", "66", "73", "74", "96", "99");
        add("Australia (+61)", "61", 9, "4");
        add("Austria (+43)", "43", 10, "660", "664", "676", "680", "699");
        add("Azerbaijan (+994)", "994", 9, "50", "51", "55", "70", "77");
        add("Bahrain (+973)", "973", 8, "32", "33", "34", "36", "38", "39");
        add("Barbados (+1)", "1", 10, "246");
        add("Belarus (+375)", "375", 9, "25", "29", "33", "44");
        add("Belgium (+32)", "32", 9, "47", "48", "49");
        add("Belize (+501)", "501", 7, "6");
        add("Benin (+229)", "229", 8, "90", "91", "95", "96", "97");
        add("Bermuda (+1)", "1", 10, "441");
        add("Bhutan (+975)", "975", 8, "17", "77");
        add("Bolivia (+591)", "591", 8, "6", "7");
        add("Bosnia and Herzegovina (+387)", "387", 8, "61", "62", "63", "65", "66");
        add("Botswana (+267)", "267", 8, "71", "72", "73", "74", "75", "76");
        add("British Virgin Islands (+1)", "1", 10, "284");
        add("Brunei (+673)", "673", 7, "7", "8");
        add("Bulgaria (+359)", "359", 9, "87", "88", "89");
        add("Burkina Faso (+226)", "226", 8, "70", "71", "76", "78");
        add("Burundi (+257)", "257", 8, "71", "76", "79");
        add("Cambodia (+855)", "855", 8, "10", "11", "12", "15", "16", "17", "69", "70", "77", "78", "85", "86", "89", "92", "93", "95", "96", "97", "98", "99");
        add("Cameroon (+237)", "237", 9, "65", "67", "68", "69");
        add("Canada (+1)", "1", 10, "416", "437", "514", "604", "647", "778", "905");
        add("Cape Verde (+238)", "238", 7, "59", "91", "95", "98", "99");
        add("Cayman Islands (+1)", "1", 10, "345");
        add("Central African Republic (+236)", "236", 8, "70", "72", "75", "77");
        add("Chad (+235)", "235", 8, "62", "63", "66", "68", "90", "99");
        add("Chile (+56)", "56", 9, "9");
        add("China (+86)", "86", 11, "13", "15", "17", "18", "19");
        add("Colombia (+57)", "57", 10, "300", "301", "310", "311", "312", "313", "314", "315", "320", "321");
        add("Comoros (+269)", "269", 7, "32", "33", "34");
        add("Costa Rica (+506)", "506", 8, "6", "7", "8");
        add("Côte d'Ivoire (+225)", "225", 10, "01", "05", "07");
        add("Croatia (+385)", "385", 9, "91", "92", "95", "98", "99");
        add("Cuba (+53)", "53", 8, "5");
        add("Cyprus (+357)", "357", 8, "95", "96", "97", "99");
        add("Czech Republic (+420)", "420", 9, "601", "602", "603", "604", "605", "606", "607", "608", "72", "73", "77");
        add("Democratic Republic of the Congo (+243)", "243", 9, "81", "82", "84", "85", "89", "97", "99");
        add("Denmark (+45)", "45", 8, "2", "30", "31", "40", "41", "42", "50", "51", "52", "60", "61");
        add("Djibouti (+253)", "253", 8, "77");
        add("Dominica (+1)", "1", 10, "767");
        add("Dominican Republic (+1)", "1", 10, "809", "829", "849");
        add("Ecuador (+593)", "593", 9, "9");
        add("Egypt (+20)", "20", 10, "10", "11", "12", "15");
        add("El Salvador (+503)", "503", 8, "6", "7");
        add("Equatorial Guinea (+240)", "240", 9, "222", "551");
        add("Eritrea (+291)", "291", 7, "7");
        add("Estonia (+372)", "372", 8, "5");
        add("Eswatini (+268)", "268", 8, "76", "78", "79");
        add("Ethiopia (+251)", "251", 9, "9");
        add("Fiji (+679)", "679", 7, "7", "8", "9");
        add("Finland (+358)", "358", 9, "40", "41", "44", "45", "50");
        add("France (+33)", "33", 9, "6", "7");
        add("French Guiana (+594)", "594", 9, "694");
        add("French Polynesia (+689)", "689", 8, "87", "89");
        add("Gabon (+241)", "241", 8, "06", "07");
        add("Georgia (+995)", "995", 9, "55", "57", "59");
        add("Germany (+49)", "49", 10, "15", "16", "17");
        add("Ghana (+233)", "233", 9, "20", "24", "26", "27", "50", "54", "55", "59");
        add("Gibraltar (+350)", "350", 8, "54", "56", "57", "58");
        add("Greece (+30)", "30", 10, "69");
        add("Greenland (+299)", "299", 6, "2", "4", "5");
        add("Grenada (+1)", "1", 10, "473");
        add("Guadeloupe (+590)", "590", 9, "690");
        add("Guam (+1)", "1", 10, "671");
        add("Guatemala (+502)", "502", 8, "3", "4", "5");
        add("Guinea (+224)", "224", 9, "62", "65", "66");
        add("Guinea-Bissau (+245)", "245", 9, "95", "96");
        add("Guyana (+592)", "592", 7, "6");
        add("Haiti (+509)", "509", 8, "3", "4");
        add("Honduras (+504)", "504", 8, "3", "8", "9");
        add("Hong Kong (+852)", "852", 8, "5", "6", "9");
        add("Hungary (+36)", "36", 9, "20", "30", "31", "70");
        add("Iceland (+354)", "354", 7, "6", "7", "8");
        add("Iran (+98)", "98", 10, "91", "92", "93", "99");
        add("Iraq (+964)", "964", 10, "75", "77", "78", "79");
        add("Ireland (+353)", "353", 9, "83", "85", "86", "87", "89");
        add("Israel (+972)", "972", 9, "50", "52", "53", "54", "58");
        add("Italy (+39)", "39", 10, "32", "33", "34", "35", "36", "37", "38", "39");
        add("Jamaica (+1)", "1", 10, "876");
        add("Japan (+81)", "81", 10, "70", "80", "90");
        add("Jordan (+962)", "962", 9, "77", "78", "79");
        add("Kazakhstan (+7)", "7", 10, "701", "702", "705", "707", "747", "771", "775", "777", "778");
        add("Kenya (+254)", "254", 9, "7");
        add("Kiribati (+686)", "686", 8, "72", "73");
        add("Kuwait (+965)", "965", 8, "5", "6", "9");
        add("Kyrgyzstan (+996)", "996", 9, "50", "55", "70", "77");
        add("Laos (+856)", "856", 10, "20");
        add("Latvia (+371)", "371", 8, "2");
        add("Lebanon (+961)", "961", 8, "3", "70", "71", "76", "78", "79", "81");
        add("Lesotho (+266)", "266", 8, "5", "6");
        add("Liberia (+231)", "231", 8, "77", "88");
        add("Libya (+218)", "218", 9, "91", "92", "94");
        add("Liechtenstein (+423)", "423", 7, "6", "7");
        add("Lithuania (+370)", "370", 8, "6");
        add("Luxembourg (+352)", "352", 9, "621", "661", "691");
        add("Macau (+853)", "853", 8, "6");
        add("Madagascar (+261)", "261", 9, "32", "33", "34", "38");
        add("Malawi (+265)", "265", 9, "88", "99");
        add("Malaysia (+60)", "60", 9, "11", "12", "13", "14", "16", "17", "18", "19");
        add("Maldives (+960)", "960", 7, "7", "9");
        add("Mali (+223)", "223", 8, "6", "7", "9");
        add("Malta (+356)", "356", 8, "77", "79", "99");
        add("Marshall Islands (+692)", "692", 7, "455");
        add("Martinique (+596)", "596", 9, "696");
        add("Mauritania (+222)", "222", 8, "2", "3", "4");
        add("Mauritius (+230)", "230", 8, "5");
        add("Mexico (+52)", "52", 10, "55", "56", "33", "81");
        add("Micronesia (+691)", "691", 7, "9");
        add("Moldova (+373)", "373", 8, "6", "7");
        add("Monaco (+377)", "377", 8, "6");
        add("Mongolia (+976)", "976", 8, "88", "89", "91", "94", "95", "99");
        add("Montenegro (+382)", "382", 8, "67", "68", "69");
        add("Montserrat (+1)", "1", 10, "664");
        add("Morocco (+212)", "212", 9, "6", "7");
        add("Mozambique (+258)", "258", 9, "82", "84", "85", "86", "87");
        add("Myanmar (+95)", "95", 9, "9");
        add("Namibia (+264)", "264", 9, "81", "85");
        add("Nauru (+674)", "674", 7, "555");
        add("Nepal (+977)", "977", 10, "98", "97");
        add("Netherlands (+31)", "31", 9, "6");
        add("New Caledonia (+687)", "687", 6, "7", "8", "9");
        add("New Zealand (+64)", "64", 9, "21", "22", "27", "29");
        add("Nicaragua (+505)", "505", 8, "5", "7", "8");
        add("Niger (+227)", "227", 8, "8", "9");
        add("Nigeria (+234)", "234", 10, "70", "80", "81", "90", "91");
        add("North Macedonia (+389)", "389", 8, "70", "71", "72", "75", "76", "77", "78");
        add("Norway (+47)", "47", 8, "4", "9");
        add("Oman (+968)", "968", 8, "7", "9");
        add("Palau (+680)", "680", 7, "77");
        add("Palestine (+970)", "970", 9, "56", "59");
        add("Panama (+507)", "507", 8, "6");
        add("Papua New Guinea (+675)", "675", 8, "7");
        add("Paraguay (+595)", "595", 9, "96", "97", "98", "99");
        add("Peru (+51)", "51", 9, "9");
        add("Philippines (+63)", "63", 10, "9");
        add("Poland (+48)", "48", 9, "50", "51", "53", "57", "60", "66", "69", "72", "73", "78", "79", "88");
        add("Portugal (+351)", "351", 9, "91", "92", "93", "96");
        add("Puerto Rico (+1)", "1", 10, "787", "939");
        add("Qatar (+974)", "974", 8, "3", "5", "6", "7");
        add("Republic of the Congo (+242)", "242", 9, "05", "06");
        add("Réunion (+262)", "262", 9, "692", "693");
        add("Romania (+40)", "40", 9, "72", "73", "74", "75", "76", "77");
        add("Russia (+7)", "7", 10, "9");
        add("Rwanda (+250)", "250", 9, "72", "73", "78", "79");
        add("Saint Barthélemy (+590)", "590", 9, "690");
        add("Saint Helena (+290)", "290", 5, "5", "6");
        add("Saint Kitts and Nevis (+1)", "1", 10, "869");
        add("Saint Martin (+590)", "590", 9, "690");
        add("Saint Pierre and Miquelon (+508)", "508", 6, "55");
        add("Saint Vincent and the Grenadines (+1)", "1", 10, "784");
        add("Samoa (+685)", "685", 7, "7");
        add("San Marino (+378)", "378", 10, "66");
        add("São Tomé and Príncipe (+239)", "239", 7, "98", "99");
        add("Saudi Arabia (+966)", "966", 9, "5");
        add("Senegal (+221)", "221", 9, "70", "76", "77", "78");
        add("Serbia (+381)", "381", 9, "60", "61", "62", "63", "64", "65", "66", "69");
        add("Seychelles (+248)", "248", 7, "2");
        add("Sierra Leone (+232)", "232", 8, "25", "30", "33", "76", "77", "78", "79", "88");
        add("Singapore (+65)", "65", 8, "8", "9");
        add("Sint Maarten (+1)", "1", 10, "721");
        add("Slovakia (+421)", "421", 9, "90", "91", "94", "95");
        add("Slovenia (+386)", "386", 8, "30", "31", "40", "41", "51", "70");
        add("Solomon Islands (+677)", "677", 7, "7", "8");
        add("Somalia (+252)", "252", 8, "61", "62", "63", "90");
        add("South Africa (+27)", "27", 9, "6", "7", "8");
        add("South Korea (+82)", "82", 10, "10");
        add("South Sudan (+211)", "211", 9, "91", "92", "95", "97");
        add("Spain (+34)", "34", 9, "6", "7");
        add("Sri Lanka (+94)", "94", 9, "7");
        add("St. Lucia (+1)", "1", 10, "758");
        add("Sudan (+249)", "249", 9, "9");
        add("Suriname (+597)", "597", 7, "7", "8");
        add("Sweden (+46)", "46", 9, "70", "72", "73", "76", "79");
        add("Switzerland (+41)", "41", 9, "76", "77", "78", "79");
        add("Syria (+963)", "963", 9, "9");
        add("Taiwan (+886)", "886", 9, "9");
        add("Tajikistan (+992)", "992", 9, "90", "91", "92", "93", "98");
        add("Tanzania (+255)", "255", 9, "6", "7");
        add("Thailand (+66)", "66", 9, "6", "8", "9");
        add("The Bahamas (+1)", "1", 10, "242");
        add("The Gambia (+220)", "220", 7, "2", "3", "7", "9");
        add("Timor-Leste (+670)", "670", 8, "77", "78");
        add("Togo (+228)", "228", 8, "90", "91", "92", "93", "96", "97", "98", "99");
        add("Tokelau (+690)", "690", 4, "3");
        add("Tonga (+676)", "676", 7, "7", "8");
        add("Trinidad and Tobago (+1)", "1", 10, "868");
        add("Tunisia (+216)", "216", 8, "2", "5", "9");
        add("Türkiye (+90)", "90", 10, "50", "53", "54", "55");
        add("Turkmenistan (+993)", "993", 8, "6");
        add("Turks and Caicos Islands (+1)", "1", 10, "649");
        add("Tuvalu (+688)", "688", 6, "70");
        add("Uganda (+256)", "256", 9, "70", "71", "75", "77", "78", "79");
        add("Ukraine (+380)", "380", 9, "50", "63", "66", "67", "68", "73", "93", "95", "96", "97", "98", "99");
        add("United Arab Emirates (+971)", "971", 9, "50", "52", "54", "55", "56", "58");
        add("Uruguay (+598)", "598", 8, "9");
        add("US Virgin Islands (+1)", "1", 10, "340");
        add("Uzbekistan (+998)", "998", 9, "90", "91", "93", "94", "95", "97", "99");
        add("Vanuatu (+678)", "678", 7, "5", "7");
        add("Vatican City (+39)", "39", 10, "3");
        add("Venezuela (+58)", "58", 10, "412", "414", "416", "424", "426");
        add("Wallis and Futuna (+681)", "681", 6, "82");
        add("Western Sahara (+212)", "212", 9, "6");
        add("Yemen (+967)", "967", 9, "7");
        add("Zambia (+260)", "260", 9, "95", "96", "97");
        add("Zimbabwe (+263)", "263", 9, "71", "73", "77", "78");
    }

    private static void add(String name, String dialCode, int length, String... prefixes) {
        COUNTRIES.add(new Country(name, dialCode, length, prefixes));
    }

    public static List<Country> getAll() {
        return COUNTRIES;
    }

    public static Country findByName(String name) {
        if (name == null) return COUNTRIES.get(0);
        for (Country c : COUNTRIES) {
            if (c.name.equalsIgnoreCase(name.trim())) return c;
        }
        return COUNTRIES.get(0);
    }
}
