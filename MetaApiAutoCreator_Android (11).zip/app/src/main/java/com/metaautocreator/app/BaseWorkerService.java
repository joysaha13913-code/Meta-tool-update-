package com.metaautocreator.app;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.View;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;

public abstract class BaseWorkerService extends Service {

    public static final int MSG_REGISTER = 1;
    public static final int MSG_RUN_CREATE = 2;
    public static final int MSG_RUN_2FA = 3;
    public static final int MSG_STOP = 4;
    public static final int MSG_SPEED = 5;

    public static final int MSG_LOG = 10;
    public static final int MSG_RESULT = 11;
    public static final int MSG_IDLE = 12;
    public static final int MSG_PREVIEW = 13;

    protected abstract int getWorkerId();

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private MetaAutomationEngine engine;
    private Messenger clientMessenger;
    private volatile boolean isRunning = false;
    private volatile double speedMult = 1.0;

    private final Runnable previewLoop = new Runnable() {
        @Override
        public void run() {
            if (isRunning && webView != null && clientMessenger != null) {
                sendPreviewSnapshot();
            }
            if (isRunning) {
                mainHandler.postDelayed(this, 850);
            }
        }
    };

    private final Messenger serviceMessenger = new Messenger(new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_REGISTER:
                    clientMessenger = msg.replyTo;
                    sendLog("Worker W" + getWorkerId() + " ready (isolated session).");
                    break;
                case MSG_SPEED:
                    Bundle sb = msg.getData();
                    speedMult = sb.getDouble("speed", 1.0);
                    break;
                case MSG_STOP:
                    isRunning = false;
                    if (webView != null) webView.stopLoading();
                    mainHandler.removeCallbacks(previewLoop);
                    sendLog("Stopping...");
                    break;
                case MSG_RUN_CREATE: {
                    Bundle b = msg.getData();
                    String pwd = b.getString("pwd", "");
                    String mailProvider = b.getString("mail", "Grab");
                    boolean with2fa = b.getBoolean("with2fa", false);
                    boolean useMuseAi = b.getBoolean("useMuseAi", true);
                    String country = b.getString("country", "Bangladesh (+880)");
                    speedMult = b.getDouble("speed", 1.0);
                    runCreateTask(pwd, mailProvider, with2fa, useMuseAi, country);
                    break;
                }
                case MSG_RUN_2FA: {
                    Bundle b = msg.getData();
                    String pwd = b.getString("pwd", "");
                    String num = b.getString("number", "");
                    speedMult = b.getDouble("speed", 1.0);
                    run2faTask(num, pwd);
                    break;
                }
            }
        }
    });

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                WebView.setDataDirectorySuffix("worker_" + getWorkerId());
            } catch (Exception ignored) {
            }
        }
        webView = new WebView(getApplicationContext());
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        webView.layout(0, 0, 1080, 1920);
        webView.onResume();
        webView.resumeTimers();

        engine = new MetaAutomationEngine(webView, mainHandler, new MetaAutomationEngine.Callback() {
            @Override
            public void onLog(String msg) {
                sendLog(msg);
            }

            @Override
            public boolean isRunning() {
                return isRunning;
            }

            @Override
            public double getSpeedMultiplier() {
                return speedMult;
            }
        });
    }

    private void sendPreviewSnapshot() {
        try {
            Bitmap bmp = Bitmap.createBitmap(480, 854, Bitmap.Config.RGB_565);
            Canvas c = new Canvas(bmp);
            c.scale(480f / 1080f, 854f / 1920f);
            webView.draw(c);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 65, baos);
            bmp.recycle();

            Message m = Message.obtain(null, MSG_PREVIEW);
            Bundle b = new Bundle();
            b.putInt("workerId", getWorkerId());
            b.putString("url", webView.getUrl() != null ? webView.getUrl() : "");
            b.putByteArray("img", baos.toByteArray());
            m.setData(b);
            clientMessenger.send(m);
        } catch (Exception ignored) {
        }
    }

    private void runCreateTask(String pwd, String mailProvider, boolean with2fa, boolean useMuseAi, String country) {
        isRunning = true;
        mainHandler.removeCallbacks(previewLoop);
        mainHandler.postDelayed(previewLoop, 1000);
        new Thread(() -> {
            String email = "N/A";
            String phone880 = "N/A";
            String twoFaKey = "N/A";
            String status = "Failed";
            try {
                engine.clearWebViewDataSync();
                MailApiHelper.MailAccount mail = MailApiHelper.createAccount(mailProvider);
                if (mail == null) throw new Exception("Mail API failed");
                email = mail.email;
                phone880 = engine.executeCreateMetaAccount(mail, mailProvider, pwd, useMuseAi, with2fa, country);
                if (with2fa) {
                    twoFaKey = engine.getLastTwoFaKey();
                }
                status = "Success";
            } catch (Exception e) {
                if ("Stopped by user".equals(e.getMessage())) {
                    sendIdle();
                    return;
                }
                sendLog("Error: " + e.getMessage());
            }
            sendResult(email, phone880, pwd, twoFaKey, status);
            sendIdle();
        }).start();
    }

    private void run2faTask(String num, String pwd) {
        isRunning = true;
        mainHandler.removeCallbacks(previewLoop);
        mainHandler.postDelayed(previewLoop, 1000);
        new Thread(() -> {
            String twoFaKey = "N/A";
            String status = "Failed";
            try {
                engine.clearWebViewDataSync();
                twoFaKey = engine.execute2faForNumber(num, pwd);
                status = "Success";
            } catch (Exception e) {
                if ("Stopped by user".equals(e.getMessage())) {
                    sendIdle();
                    return;
                }
                sendLog("Error: " + e.getMessage());
            }
            sendResult(num, num, pwd, twoFaKey, status);
            sendIdle();
        }).start();
    }

    private void sendLog(String text) {
        if (clientMessenger == null) return;
        try {
            Message m = Message.obtain(null, MSG_LOG);
            Bundle b = new Bundle();
            b.putInt("workerId", getWorkerId());
            b.putString("text", text);
            m.setData(b);
            clientMessenger.send(m);
        } catch (Exception ignored) {
        }
    }

    private void sendResult(String email, String phone, String pwd, String twoFaKey, String status) {
        if (clientMessenger == null) return;
        try {
            Message m = Message.obtain(null, MSG_RESULT);
            Bundle b = new Bundle();
            b.putInt("workerId", getWorkerId());
            b.putString("email", email);
            b.putString("phone", phone);
            b.putString("pwd", pwd);
            b.putString("twoFaKey", twoFaKey);
            b.putString("status", status);
            m.setData(b);
            clientMessenger.send(m);
        } catch (Exception ignored) {
        }
    }

    private void sendIdle() {
        isRunning = false;
        mainHandler.removeCallbacks(previewLoop);
        if (clientMessenger == null) return;
        try {
            Message m = Message.obtain(null, MSG_IDLE);
            Bundle b = new Bundle();
            b.putInt("workerId", getWorkerId());
            m.setData(b);
            clientMessenger.send(m);
        } catch (Exception ignored) {
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return serviceMessenger.getBinder();
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        mainHandler.removeCallbacks(previewLoop);
        if (webView != null) {
            mainHandler.post(() -> webView.destroy());
        }
        super.onDestroy();
    }
}
