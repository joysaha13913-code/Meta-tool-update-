package com.metaautocreator.app;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Queue;

public class MainActivity extends AppCompatActivity {

    public static class ResultItem {
        public String email;
        public String phone;
        public String password;
        public String twoFaKey;
        public String status;
        public String timestamp;

        public ResultItem(String email, String phone, String password, String twoFaKey, String status, String timestamp) {
            this.email = email;
            this.phone = phone;
            this.password = password;
            this.twoFaKey = twoFaKey;
            this.status = status;
            this.timestamp = timestamp;
        }
    }

    private TextView tvSuccess, tvFailed, tvActiveWorkers, tvStatus, tvUrl, tvResultsList, tvTerminalLog, tvTerminalInfo;
    private EditText etPassword, et2faNumbers, etTotalTarget;
    private Spinner spMail, spSpeed, spWorkers;
    private CheckBox cbWith2fa, cb2faOnly;
    private ScrollView panelControls, scrollTerminal;
    private LinearLayout panelTerminal, panelBrowser, panel2fa, panelResults;
    private Button btnTabControls, btnTabTerminal, btnTabBrowser, btnTab2fa, btnTabResults;
    private EditText etPaste2faSecret;
    private TextView tvLiveTotpCode, tvTotpTimer;
    private ProgressBar pbTotpTimer;
    private WebView webView;
    private ImageView ivWorkerPreview;
    private LinearLayout llBrowserWorkers;
    private int selectedBrowserWorker = 1;
    private final String[] workerUrls = new String[6];
    private final Bitmap[] workerPreviews = new Bitmap[6];
    private final Button[] browserWorkerBtns = new Button[6];
    private MetaAutomationEngine w1Engine;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean isRunning = false;
    private int successCount = 0;
    private int failedCount = 0;
    private final List<ResultItem> results = new ArrayList<>();
    private final List<String> terminalLines = new ArrayList<>();

    // Orchestration state
    private int configuredWorkers = 1;
    private int totalTarget = 0;
    private int dispatchedCount = 0;
    private boolean activeRun2faOnly = false;
    private boolean activeWith2fa = false;
    private String activePwd = "";
    private String activeMailProvider = "Grab";
    private final Queue<String> queue2fa = new ArrayDeque<>();
    private final boolean[] workerBusy = new boolean[6]; // 1..5

    // Isolated Worker Services (2..5)
    private final Messenger[] remoteMessengers = new Messenger[6];
    private final boolean[] serviceBound = new boolean[6];
    private final ServiceConnection[] serviceConnections = new ServiceConnection[6];

    private final Messenger clientMessenger = new Messenger(new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            Bundle b = msg.getData();
            int wid = b.getInt("workerId", 0);
            switch (msg.what) {
                case BaseWorkerService.MSG_LOG:
                    appendTerminalLog(wid, b.getString("text", ""));
                    break;
                case BaseWorkerService.MSG_RESULT:
                    addResult(
                        b.getString("email", "N/A"),
                        b.getString("phone", "N/A"),
                        b.getString("pwd", ""),
                        b.getString("twoFaKey", "N/A"),
                        b.getString("status", "Failed")
                    );
                    break;
                case BaseWorkerService.MSG_IDLE:
                    onWorkerFinished(wid);
                    break;
                case BaseWorkerService.MSG_PREVIEW:
                    byte[] img = b.getByteArray("img");
                    String pUrl = b.getString("url", "");
                    if (wid >= 2 && wid <= 5) {
                        workerUrls[wid] = pUrl;
                        if (img != null && img.length > 0) {
                            Bitmap bmp = BitmapFactory.decodeByteArray(img, 0, img.length);
                            if (bmp != null) {
                                workerPreviews[wid] = bmp;
                                if (selectedBrowserWorker == wid) {
                                    ivWorkerPreview.setImageBitmap(bmp);
                                    tvUrl.setText("W" + wid + ": " + pUrl);
                                }
                            }
                        }
                    }
                    break;
            }
        }
    });

    private ActivityResultLauncher<String[]> openTxtLauncher;
    private ActivityResultLauncher<String> saveTxtLauncher;
    private ActivityResultLauncher<String> saveXlsxLauncher;

    private final Runnable totpTicker = new Runnable() {
        @Override
        public void run() {
            updateLiveTotpUi();
            mainHandler.postDelayed(this, 1000);
        }
    };

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSuccess = findViewById(R.id.tvSuccess);
        tvFailed = findViewById(R.id.tvFailed);
        tvActiveWorkers = findViewById(R.id.tvActiveWorkers);
        tvStatus = findViewById(R.id.tvStatus);
        tvUrl = findViewById(R.id.tvUrl);
        tvResultsList = findViewById(R.id.tvResultsList);
        tvTerminalLog = findViewById(R.id.tvTerminalLog);
        tvTerminalInfo = findViewById(R.id.tvTerminalInfo);
        scrollTerminal = findViewById(R.id.scrollTerminal);

        etPassword = findViewById(R.id.etPassword);
        et2faNumbers = findViewById(R.id.et2faNumbers);
        etTotalTarget = findViewById(R.id.etTotalTarget);
        spMail = findViewById(R.id.spMail);
        spSpeed = findViewById(R.id.spSpeed);
        spWorkers = findViewById(R.id.spWorkers);
        cbWith2fa = findViewById(R.id.cbWith2fa);
        cb2faOnly = findViewById(R.id.cb2faOnly);

        panelControls = findViewById(R.id.panelControls);
        panelTerminal = findViewById(R.id.panelTerminal);
        panelBrowser = findViewById(R.id.panelBrowser);
        panel2fa = findViewById(R.id.panel2fa);
        panelResults = findViewById(R.id.panelResults);

        btnTabControls = findViewById(R.id.btnTabControls);
        btnTabTerminal = findViewById(R.id.btnTabTerminal);
        btnTabBrowser = findViewById(R.id.btnTabBrowser);
        btnTab2fa = findViewById(R.id.btnTab2fa);
        btnTabResults = findViewById(R.id.btnTabResults);

        etPaste2faSecret = findViewById(R.id.etPaste2faSecret);
        tvLiveTotpCode = findViewById(R.id.tvLiveTotpCode);
        tvTotpTimer = findViewById(R.id.tvTotpTimer);
        pbTotpTimer = findViewById(R.id.pbTotpTimer);
        webView = findViewById(R.id.webView);
        ivWorkerPreview = findViewById(R.id.ivWorkerPreview);
        llBrowserWorkers = findViewById(R.id.llBrowserWorkers);
        rebuildBrowserWorkerTabs(1);

        spMail.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Grab", "Guerrilla"}));
        spSpeed.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"1x", "2x", "3x", "4x", "5x"}));
        spWorkers.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"1 Worker", "2 Workers", "3 Workers", "4 Workers", "5 Workers"}));

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                workerUrls[1] = url != null ? url : "";
                if (selectedBrowserWorker == 1) {
                    tvUrl.setText("W1: " + workerUrls[1]);
                }
            }
        });

        w1Engine = new MetaAutomationEngine(webView, mainHandler, new MetaAutomationEngine.Callback() {
            @Override
            public void onLog(String msg) {
                appendTerminalLog(1, msg);
            }

            @Override
            public boolean isRunning() {
                return isRunning;
            }

            @Override
            public double getSpeedMultiplier() {
                return getSpeedMultiplierValue();
            }
        });

        openTxtLauncher = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri != null) loadNumbersFromUri(uri);
        });
        saveTxtLauncher = registerForActivityResult(new ActivityResultContracts.CreateDocument("text/plain"), uri -> {
            if (uri != null) exportResultsTxtToUri(uri);
        });
        saveXlsxLauncher = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"), uri -> {
            if (uri != null) exportResultsXlsxToUri(uri);
        });

        btnTabControls.setOnClickListener(v -> switchTab(0));
        btnTabTerminal.setOnClickListener(v -> switchTab(1));
        btnTabBrowser.setOnClickListener(v -> switchTab(2));
        btnTab2fa.setOnClickListener(v -> switchTab(3));
        btnTabResults.setOnClickListener(v -> switchTab(4));

        etPaste2faSecret.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateLiveTotpUi(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        findViewById(R.id.btnPaste2fa).setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence txt = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                if (txt != null) etPaste2faSecret.setText(txt.toString().trim());
            }
        });
        findViewById(R.id.btnClear2fa).setOnClickListener(v -> {
            etPaste2faSecret.setText("");
            etPaste2faSecret.requestFocus();
            updateLiveTotpUi();
        });
        findViewById(R.id.btnCopyLiveTotp).setOnClickListener(v -> {
            String code = tvLiveTotpCode.getText().toString().replace(" ", "").trim();
            if (!code.isEmpty() && !code.contains("-")) {
                copyToClipboard("2FA Code", code);
            } else {
                Toast.makeText(this, "Paste a valid 2FA key first!", Toast.LENGTH_SHORT).show();
            }
        });
        mainHandler.post(totpTicker);

        findViewById(R.id.btnReloadWeb).setOnClickListener(v -> webView.reload());
        findViewById(R.id.btnClearBrowser).setOnClickListener(v -> {
            w1Engine.clearWebViewDataSync();
            appendTerminalLog(0, "Browser cookies & cache cleared.");
            Toast.makeText(this, "Browser data cleared!", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnCopyTerminal).setOnClickListener(v -> copyToClipboard("Terminal Log", tvTerminalLog.getText().toString()));
        findViewById(R.id.btnClearTerminal).setOnClickListener(v -> {
            synchronized (terminalLines) {
                terminalLines.clear();
            }
            tvTerminalLog.setText("$ Terminal cleared.\n");
        });

        findViewById(R.id.btnLoadCreated).setOnClickListener(v -> loadCreatedNumbers());
        findViewById(R.id.btnLoadTxt).setOnClickListener(v -> openTxtLauncher.launch(new String[]{"text/plain", "*/*"}));

        findViewById(R.id.btnStart).setOnClickListener(v -> startAutomation(false));
        findViewById(R.id.btnStart2fa).setOnClickListener(v -> startAutomation(true));
        findViewById(R.id.btnStop).setOnClickListener(v -> stopAutomation());

        findViewById(R.id.btnCopyAll).setOnClickListener(v -> copyAllResults());
        findViewById(R.id.btnCopyNumbers).setOnClickListener(v -> copyNumbersOnly());
        findViewById(R.id.btnCopyPasswords).setOnClickListener(v -> copyPasswordsOnly());
        findViewById(R.id.btnCopy2fa).setOnClickListener(v -> copy2faKeysOnly());
        findViewById(R.id.btnExportXlsx).setOnClickListener(v -> {
            String ts = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
            saveXlsxLauncher.launch("meta_accounts_" + ts + ".xlsx");
        });
        findViewById(R.id.btnExportTxt).setOnClickListener(v -> saveTxtLauncher.launch("meta_accounts.txt"));
        findViewById(R.id.btnClearAll).setOnClickListener(v -> clearAllResults());
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    private void rebuildBrowserWorkerTabs(int count) {
        llBrowserWorkers.removeAllViews();
        for (int i = 1; i <= count; i++) {
            final int wid = i;
            Button btn = new Button(this);
            btn.setText("W" + wid + (wid == 1 ? " (Live)" : " (View)"));
            btn.setTextSize(11f);
            btn.setAllCaps(false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                (int) (34 * getResources().getDisplayMetrics().density)
            );
            lp.setMarginEnd((int) (6 * getResources().getDisplayMetrics().density));
            btn.setLayoutParams(lp);
            btn.setOnClickListener(v -> selectBrowserWorker(wid));
            browserWorkerBtns[wid] = btn;
            llBrowserWorkers.addView(btn);
        }
        selectBrowserWorker(1);
    }

    private void selectBrowserWorker(int wid) {
        selectedBrowserWorker = wid;
        for (int i = 1; i <= 5; i++) {
            if (browserWorkerBtns[i] != null) {
                boolean sel = (i == wid);
                browserWorkerBtns[i].setBackgroundTintList(android.content.res.ColorStateList.valueOf(sel ? 0xFF00E5FF : 0xFF2A2A2A));
                browserWorkerBtns[i].setTextColor(sel ? 0xFF121212 : 0xFFFFFFFF);
            }
        }
        if (wid == 1) {
            webView.setVisibility(View.VISIBLE);
            ivWorkerPreview.setVisibility(View.GONE);
            tvUrl.setText("W1: " + (workerUrls[1] != null ? workerUrls[1] : "about:blank"));
        } else {
            webView.setVisibility(View.GONE);
            ivWorkerPreview.setVisibility(View.VISIBLE);
            if (workerPreviews[wid] != null) {
                ivWorkerPreview.setImageBitmap(workerPreviews[wid]);
            } else {
                ivWorkerPreview.setImageDrawable(null);
            }
            tvUrl.setText("W" + wid + ": " + (workerUrls[wid] != null ? workerUrls[wid] : "Loading..."));
        }
    }

    private void switchTab(int idx) {
        panelControls.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        panelTerminal.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        panelBrowser.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        panel2fa.setVisibility(idx == 3 ? View.VISIBLE : View.GONE);
        panelResults.setVisibility(idx == 4 ? View.VISIBLE : View.GONE);

        Button[] tabs = {btnTabControls, btnTabTerminal, btnTabBrowser, btnTab2fa, btnTabResults};
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setBackgroundTintList(android.content.res.ColorStateList.valueOf(i == idx ? 0xFFFFD700 : 0xFF222630));
            tabs[i].setTextColor(i == idx ? 0xFF0E1117 : (i == 3 ? 0xFF00E5FF : 0xFFFFFFFF));
        }
    }

    private void updateLiveTotpUi() {
        if (etPaste2faSecret == null) return;
        String raw = etPaste2faSecret.getText().toString().replaceAll("\\s+", "").toUpperCase(Locale.US);
        int rem = TotpHelper.getRemainingSeconds();
        pbTotpTimer.setProgress(rem);
        if (raw.length() < 8) {
            tvLiveTotpCode.setText("------");
            tvTotpTimer.setText("Paste 2FA key to auto-generate (" + rem + "s)");
            return;
        }
        String code = null;
        try {
            code = TotpHelper.generateTotp(raw);
        } catch (Exception ignored) {
        }
        if (code != null && code.length() == 6) {
            tvLiveTotpCode.setText(code.substring(0, 3) + " " + code.substring(3));
            tvTotpTimer.setText("Refreshes in " + rem + "s (Auto 30s loop)");
        } else {
            tvLiveTotpCode.setText("ERROR");
            tvTotpTimer.setText("Invalid Base32 2FA key");
        }
    }

    private double getSpeedMultiplierValue() {
        try {
            String s = spSpeed.getSelectedItem().toString().replace("x", "").trim();
            return Math.max(1.0, Math.min(5.0, Double.parseDouble(s)));
        } catch (Exception e) {
            return 1.0;
        }
    }

    private int getSelectedWorkerCount() {
        return Math.max(1, Math.min(5, spWorkers.getSelectedItemPosition() + 1));
    }

    private void appendTerminalLog(int workerId, String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        String tag = workerId > 0 ? ("[W" + workerId + "]") : "[SYS]";
        String line = "[" + ts + "] " + tag + " " + msg;
        mainHandler.post(() -> {
            tvStatus.setText("Status: " + tag + " " + msg);
            synchronized (terminalLines) {
                terminalLines.add(line);
                if (terminalLines.size() > 350) {
                    terminalLines.remove(0);
                }
                StringBuilder sb = new StringBuilder();
                for (String l : terminalLines) sb.append(l).append("\n");
                tvTerminalLog.setText(sb.toString());
            }
            scrollTerminal.post(() -> scrollTerminal.fullScroll(View.FOCUS_DOWN));
        });
    }

    private void updateActiveWorkersBadge() {
        int active = 0;
        for (int i = 1; i <= 5; i++) if (workerBusy[i]) active++;
        int fActive = active;
        mainHandler.post(() -> {
            tvActiveWorkers.setText("Workers: " + fActive + "/" + configuredWorkers);
            tvTerminalInfo.setText("IN-APP TERMINAL | ACTIVE: " + fActive + "/" + configuredWorkers +
                (totalTarget > 0 ? (" | TARGET: " + dispatchedCount + "/" + totalTarget) : " | LOOP"));
        });
    }

    private Class<?> getWorkerServiceClass(int wid) {
        switch (wid) {
            case 2: return WorkerService2.class;
            case 3: return WorkerService3.class;
            case 4: return WorkerService4.class;
            case 5: return WorkerService5.class;
            default: return null;
        }
    }

    private void ensureRemoteWorkersBound(int count, Runnable onReady) {
        if (count <= 1) {
            onReady.run();
            return;
        }
        for (int wid = 2; wid <= count; wid++) {
            final int id = wid;
            if (!serviceBound[id]) {
                serviceConnections[id] = new ServiceConnection() {
                    @Override
                    public void onServiceConnected(ComponentName name, IBinder service) {
                        remoteMessengers[id] = new Messenger(service);
                        serviceBound[id] = true;
                        try {
                            Message reg = Message.obtain(null, BaseWorkerService.MSG_REGISTER);
                            reg.replyTo = clientMessenger;
                            remoteMessengers[id].send(reg);
                        } catch (Exception ignored) {
                        }
                    }

                    @Override
                    public void onServiceDisconnected(ComponentName name) {
                        remoteMessengers[id] = null;
                        serviceBound[id] = false;
                    }
                };
                bindService(new Intent(this, getWorkerServiceClass(id)), serviceConnections[id], Context.BIND_AUTO_CREATE);
            }
        }
        new Thread(() -> {
            long end = System.currentTimeMillis() + 3500;
            while (System.currentTimeMillis() < end) {
                boolean allReady = true;
                for (int wid = 2; wid <= count; wid++) {
                    if (remoteMessengers[wid] == null) {
                        allReady = false;
                        break;
                    }
                }
                if (allReady) break;
                try { Thread.sleep(100); } catch (InterruptedException ignored) {}
            }
            mainHandler.post(onReady);
        }).start();
    }

    private void startAutomation(boolean force2fa) {
        if (isRunning) {
            Toast.makeText(this, "Already running!", Toast.LENGTH_SHORT).show();
            return;
        }
        String pwd = etPassword.getText().toString().trim();
        if (pwd.isEmpty()) {
            Toast.makeText(this, "Enter password first!", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean run2faOnly = force2fa || cb2faOnly.isChecked();
        boolean with2fa = cbWith2fa.isChecked();
        String mailProvider = spMail.getSelectedItem().toString();
        int workers = getSelectedWorkerCount();

        int target = 0;
        try {
            String tStr = etTotalTarget.getText().toString().trim();
            if (!tStr.isEmpty()) target = Math.max(0, Integer.parseInt(tStr));
        } catch (Exception ignored) {}

        synchronized (queue2fa) {
            queue2fa.clear();
            if (run2faOnly) {
                String raw = et2faNumbers.getText().toString().trim();
                for (String ln : raw.split("\\r?\\n")) {
                    if (!ln.trim().isEmpty()) queue2fa.add(ln.trim());
                }
                if (queue2fa.isEmpty()) {
                    for (ResultItem r : results) {
                        if ("Success".equals(r.status) && r.phone != null && !"N/A".equals(r.phone)) {
                            queue2fa.add(r.phone);
                        }
                    }
                }
                if (queue2fa.isEmpty()) {
                    Toast.makeText(this, "Enter 2FA numbers or click Load Created!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }

        configuredWorkers = workers;
        totalTarget = target;
        dispatchedCount = 0;
        activeRun2faOnly = run2faOnly;
        activeWith2fa = with2fa;
        activePwd = pwd;
        activeMailProvider = mailProvider;
        isRunning = true;

        rebuildBrowserWorkerTabs(workers);
        selectBrowserWorker(1);
        startBgService("Running " + workers + " worker(s) | Success: " + successCount + " | Failed: " + failedCount);
        switchTab(1); // Open In-App Terminal automatically
        appendTerminalLog(0, "Starting " + workers + " parallel worker(s) inside app terminal (no external windows)...");

        ensureRemoteWorkersBound(workers, () -> {
            if (!isRunning) return;
            for (int wid = 1; wid <= configuredWorkers; wid++) {
                dispatchNextForWorker(wid);
            }
        });
    }

    private synchronized void dispatchNextForWorker(int wid) {
        if (!isRunning) {
            checkAllWorkersStopped();
            return;
        }
        if (activeRun2faOnly) {
            String nextNum;
            synchronized (queue2fa) {
                nextNum = queue2fa.poll();
            }
            if (nextNum == null) {
                checkAllWorkersStopped();
                return;
            }
            workerBusy[wid] = true;
            updateActiveWorkersBadge();
            if (wid == 1) {
                runW12faTask(nextNum);
            } else {
                sendRemote2faTask(wid, nextNum);
            }
        } else {
            if (totalTarget > 0 && dispatchedCount >= totalTarget) {
                checkAllWorkersStopped();
                return;
            }
            dispatchedCount++;
            workerBusy[wid] = true;
            updateActiveWorkersBadge();
            if (wid == 1) {
                runW1CreateTask();
            } else {
                sendRemoteCreateTask(wid);
            }
        }
    }

    private synchronized void onWorkerFinished(int wid) {
        workerBusy[wid] = false;
        updateActiveWorkersBadge();
        dispatchNextForWorker(wid);
    }

    private synchronized void checkAllWorkersStopped() {
        for (int i = 1; i <= 5; i++) {
            if (workerBusy[i]) return;
        }
        if (isRunning) {
            isRunning = false;
            stopBgService();
            appendTerminalLog(0, "All tasks completed.");
        }
        updateActiveWorkersBadge();
    }

    private void runW1CreateTask() {
        new Thread(() -> {
            String email = "N/A";
            String phone880 = "N/A";
            String twoFaKey = "N/A";
            String status = "Failed";
            try {
                w1Engine.clearWebViewDataSync();
                MailApiHelper.MailAccount mail = MailApiHelper.createAccount(activeMailProvider);
                if (mail == null) throw new Exception("Mail API failed");
                email = mail.email;
                phone880 = w1Engine.executeCreateMetaAccount(mail, activeMailProvider, activePwd);
                if (activeWith2fa) {
                    appendTerminalLog(1, "Clearing data & starting 2FA for " + phone880 + "...");
                    w1Engine.clearWebViewDataSync();
                    Thread.sleep(1000);
                    twoFaKey = w1Engine.execute2faForNumber(phone880, activePwd);
                }
                status = "Success";
            } catch (Exception e) {
                if ("Stopped by user".equals(e.getMessage())) {
                    onWorkerFinished(1);
                    return;
                }
                appendTerminalLog(1, "Error: " + e.getMessage());
            }
            addResult(email, phone880, activePwd, twoFaKey, status);
            onWorkerFinished(1);
        }).start();
    }

    private void runW12faTask(String num) {
        new Thread(() -> {
            String twoFaKey = "N/A";
            String status = "Failed";
            try {
                w1Engine.clearWebViewDataSync();
                twoFaKey = w1Engine.execute2faForNumber(num, activePwd);
                status = "Success";
            } catch (Exception e) {
                if ("Stopped by user".equals(e.getMessage())) {
                    onWorkerFinished(1);
                    return;
                }
                appendTerminalLog(1, "Error: " + e.getMessage());
            }
            addResult(num, num, activePwd, twoFaKey, status);
            onWorkerFinished(1);
        }).start();
    }

    private void sendRemoteCreateTask(int wid) {
        Messenger m = remoteMessengers[wid];
        if (m == null) {
            appendTerminalLog(wid, "Service not connected.");
            onWorkerFinished(wid);
            return;
        }
        try {
            Message msg = Message.obtain(null, BaseWorkerService.MSG_RUN_CREATE);
            Bundle b = new Bundle();
            b.putString("pwd", activePwd);
            b.putString("mail", activeMailProvider);
            b.putBoolean("with2fa", activeWith2fa);
            b.putDouble("speed", getSpeedMultiplierValue());
            msg.setData(b);
            m.send(msg);
        } catch (Exception e) {
            onWorkerFinished(wid);
        }
    }

    private void sendRemote2faTask(int wid, String number) {
        Messenger m = remoteMessengers[wid];
        if (m == null) {
            appendTerminalLog(wid, "Service not connected.");
            onWorkerFinished(wid);
            return;
        }
        try {
            Message msg = Message.obtain(null, BaseWorkerService.MSG_RUN_2FA);
            Bundle b = new Bundle();
            b.putString("pwd", activePwd);
            b.putString("number", number);
            b.putDouble("speed", getSpeedMultiplierValue());
            msg.setData(b);
            m.send(msg);
        } catch (Exception e) {
            onWorkerFinished(wid);
        }
    }

    private void stopAutomation() {
        isRunning = false;
        stopBgService();
        for (int i = 1; i <= 5; i++) workerBusy[i] = false;
        updateActiveWorkersBadge();
        mainHandler.post(() -> {
            if (webView != null) webView.stopLoading();
            tvStatus.setText("Status: Stopped");
        });
        appendTerminalLog(0, "STOPPED immediately.");
        for (int wid = 2; wid <= 5; wid++) {
            if (remoteMessengers[wid] != null) {
                try {
                    remoteMessengers[wid].send(Message.obtain(null, BaseWorkerService.MSG_STOP));
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void addResult(String email, String phone, String pwd, String twoFaKey, String status) {
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        ResultItem item = new ResultItem(email, phone, pwd, twoFaKey, status, ts);
        synchronized (results) {
            results.add(item);
            if ("Success".equals(status)) successCount++;
            else failedCount++;
        }
        saveLineToInternalFile(item);
        appendTerminalLog(0, "Result [" + status + "] " + phone + " | 2FA: " + twoFaKey);
        if (isRunning) {
            updateBgService("Success: " + successCount + " | Failed: " + failedCount + " | Workers: " + configuredWorkers);
        }
        mainHandler.post(() -> {
            tvSuccess.setText("Success: " + successCount);
            tvFailed.setText("Failed: " + failedCount);
            refreshResultsText();
        });
    }

    private void saveLineToInternalFile(ResultItem r) {
        try {
            File f = new File(getFilesDir(), "created_accounts.txt");
            FileWriter fw = new FileWriter(f, true);
            fw.write(String.format(Locale.US, "Acc: %s | Num: %s | Pass: %s | 2FA: %s | %s%n",
                    r.email, r.phone, r.password, r.twoFaKey, r.status));
            fw.close();
        } catch (Exception ignored) {
        }
    }

    private void refreshResultsText() {
        StringBuilder sb = new StringBuilder();
        synchronized (results) {
            for (int i = 0; i < results.size(); i++) {
                ResultItem r = results.get(i);
                sb.append(i + 1).append(". [").append(r.status).append("] ")
                  .append(r.phone).append(" | ").append(r.password)
                  .append(" | 2FA: ").append(r.twoFaKey).append("\n");
            }
        }
        tvResultsList.setText(sb.length() > 0 ? sb.toString() : "No accounts yet.");
    }

    private void copyToClipboard(String label, String text) {
        if (text.isEmpty()) {
            Toast.makeText(this, "Nothing to copy!", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, text));
        Toast.makeText(this, label + " copied!", Toast.LENGTH_SHORT).show();
    }

    private void copyAllResults() {
        StringBuilder sb = new StringBuilder();
        synchronized (results) {
            for (ResultItem r : results) {
                if ("Success".equals(r.status)) {
                    sb.append("Acc: ").append(r.email).append(" | Number: ").append(r.phone)
                      .append(" | Password: ").append(r.password).append(" | 2FA: ").append(r.twoFaKey).append("\n");
                }
            }
        }
        copyToClipboard("All Accounts", sb.toString().trim());
    }

    private void copyNumbersOnly() {
        StringBuilder sb = new StringBuilder();
        synchronized (results) {
            for (ResultItem r : results) {
                if ("Success".equals(r.status) && r.phone != null && !"N/A".equals(r.phone)) sb.append(r.phone).append("\n");
            }
        }
        copyToClipboard("Numbers", sb.toString().trim());
    }

    private void copyPasswordsOnly() {
        StringBuilder sb = new StringBuilder();
        synchronized (results) {
            for (ResultItem r : results) {
                if ("Success".equals(r.status)) sb.append(r.password).append("\n");
            }
        }
        copyToClipboard("Passwords", sb.toString().trim());
    }

    private void copy2faKeysOnly() {
        StringBuilder sb = new StringBuilder();
        synchronized (results) {
            for (ResultItem r : results) {
                if ("Success".equals(r.status) && r.twoFaKey != null && !"N/A".equals(r.twoFaKey)) sb.append(r.twoFaKey).append("\n");
            }
        }
        copyToClipboard("2FA Keys", sb.toString().trim());
    }

    private void loadCreatedNumbers() {
        StringBuilder sb = new StringBuilder();
        synchronized (results) {
            for (ResultItem r : results) {
                if ("Success".equals(r.status) && r.phone != null && !"N/A".equals(r.phone)) sb.append(r.phone).append("\n");
            }
        }
        if (sb.length() > 0) {
            et2faNumbers.setText(sb.toString().trim());
            Toast.makeText(this, "Created numbers loaded!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No created numbers yet!", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadNumbersFromUri(Uri uri) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) sb.append(line.trim()).append("\n");
            }
            et2faNumbers.setText(sb.toString().trim());
            cb2faOnly.setChecked(true);
            Toast.makeText(this, "Numbers loaded from .txt!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to load file", Toast.LENGTH_SHORT).show();
        }
    }

    private void exportResultsTxtToUri(Uri uri) {
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            StringBuilder sb = new StringBuilder();
            synchronized (results) {
                for (ResultItem r : results) {
                    sb.append("Acc: ").append(r.email).append(" | Number: ").append(r.phone)
                      .append(" | Password: ").append(r.password).append(" | 2FA: ").append(r.twoFaKey)
                      .append(" | Status: ").append(r.status).append("\n");
                }
            }
            os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Saved .txt successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export .txt failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void exportResultsXlsxToUri(Uri uri) {
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            List<ResultItem> snapshot;
            synchronized (results) {
                snapshot = new ArrayList<>(results);
            }
            XlsxExporter.export(os, snapshot);
            Toast.makeText(this, "Excel (.xlsx) downloaded successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Excel export failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void clearAllResults() {
        synchronized (results) {
            results.clear();
            successCount = 0;
            failedCount = 0;
        }
        tvSuccess.setText("Success: 0");
        tvFailed.setText("Failed: 0");
        refreshResultsText();
        Toast.makeText(this, "Cleared all!", Toast.LENGTH_SHORT).show();
    }

    private void startBgService(String text) {
        try {
            Intent i = new Intent(this, KeepAliveService.class);
            i.setAction(KeepAliveService.ACTION_START);
            i.putExtra("text", text);
            ContextCompat.startForegroundService(this, i);
        } catch (Exception ignored) {
        }
    }

    private void updateBgService(String text) {
        try {
            Intent i = new Intent(this, KeepAliveService.class);
            i.setAction(KeepAliveService.ACTION_UPDATE);
            i.putExtra("text", text);
            startService(i);
        } catch (Exception ignored) {
        }
    }

    private void stopBgService() {
        try {
            Intent i = new Intent(this, KeepAliveService.class);
            i.setAction(KeepAliveService.ACTION_STOP);
            startService(i);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isRunning && webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacks(totpTicker);
        stopBgService();
        isRunning = false;
        for (int wid = 2; wid <= 5; wid++) {
            if (serviceBound[wid] && serviceConnections[wid] != null) {
                try {
                    unbindService(serviceConnections[wid]);
                } catch (Exception ignored) {
                }
                serviceBound[wid] = false;
            }
        }
        super.onDestroy();
    }
}
